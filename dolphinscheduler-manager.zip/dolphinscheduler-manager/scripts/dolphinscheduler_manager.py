#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DolphinScheduler API 客户端
Apache DolphinScheduler 集群管理工具集，提供完整的 REST API 封装

功能特性:
  - 统一 Token 认证，兼容大多数 DolphinScheduler 版本
  - 18+ 管理功能，覆盖项目/工作流/任务/定时调度全生命周期
  - 内置 DataX 任务创建助手
  - 支持命令行直接调用，方便脚本自动化
  - 完善的异常处理和日志输出

支持环境变量配置:
  - DOLPHINSCHEDULER_BASE_URL: API 地址 (默认: http://olds.bigdata.shiqiao.com)
  - DOLPHINSCHEDULER_TOKEN: API 访问令牌 (默认值已内置)

 maintained by: shiqiao-bigdata
"""
import sys
import os
import requests
import urllib3
import json
import logging
import ast
import time
import uuid
import argparse
from typing import List, Dict, Optional, Union
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, as_completed

# 配置日志格式
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 关闭 SSL 警告（内网环境通常使用自签名证书）
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def print_table(data: List[Dict], headers: List[str], fields: List[str]):
    """
    打印格式化的表格
    :param data: 数据列表
    :param headers: 表头列表
    :param fields: 对应的字段名列表
    """
    if not data:
        print("无数据")
        return

    # 计算每列的最大宽度
    col_widths = [len(header) for header in headers]
    for row in data:
        for i, field in enumerate(fields):
            value = str(row.get(field, ""))
            if len(value) > col_widths[i]:
                col_widths[i] = len(value)

    # 打印表头
    header_line = "| " + " | ".join([headers[i].ljust(col_widths[i]) for i in range(len(headers))]) + " |"
    print(header_line)
    print("-" * len(header_line))

    # 打印所有数据行
    for row in data:
        row_data = []
        for i, field in enumerate(fields):
            value = str(row.get(field, ""))
            row_data.append(value.ljust(col_widths[i]))
        print("| " + " | ".join(row_data) + " |")

    print(f"\n总记录数: {len(data)}")


def retry(max_retries: int = 3, delay: int = 1):
    """
    重试装饰器，对幂等API请求进行自动重试
    :param max_retries: 最大重试次数
    :param delay: 重试间隔（秒）
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except (requests.exceptions.RequestException, ConnectionError, TimeoutError) as e:
                    if attempt == max_retries - 1:
                        logger.error(f"请求失败，已重试{max_retries}次: {e}")
                        raise
                    logger.warning(f"请求失败，{delay}秒后重试: {e}")
                    time.sleep(delay)
            return None
        return wrapper
    return decorator


class DolphinSchedulerAPIClient:
    """
    DolphinScheduler API 客户端

    封装所有 DolphinScheduler 管理操作，提供简洁的 Python 接口和命令行接口。
    """
    def __init__(self, base_url: str = None, token: str = None, timeout: int = 15, timing_enabled: bool = False):
        """
        初始化客户端（统一Token认证）
        :param base_url: DolphinScheduler地址，如 http://olds.bigdata.shiqiao.com
        :param token: API Token
        :param timeout: 请求超时时间（秒），默认15
        :param timing_enabled: 是否开启耗时统计，默认关闭（测试阶段开启）
        """
        # 从环境变量读取默认配置，未提供则使用内置默认值
        self.base_url = (base_url or os.getenv("DOLPHINSCHEDULER_BASE_URL", "http://olds.bigdata.shiqiao.com")).rstrip('/')
        self.token = token or os.getenv("DOLPHINSCHEDULER_TOKEN", "0d133fb5d24e3c3d63b14c759c198a7b")
        self.timeout = timeout
        self.timing_enabled = timing_enabled
        # 耗时统计存储
        self._timing_stats = {
            "total_time": 0,
            "api_requests": [],
            "table_processing": [],
            "start_time": 0
        }
        self.headers = {
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Connection": "keep-alive",
            "Referer": f"{self.base_url}/dolphinscheduler/ui/",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
            "language": "zh_CN",
            "token": self.token
        }
        # 创建连接池复用HTTP连接
        self.session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(pool_connections=10, pool_maxsize=20)
        self.session.mount('http://', adapter)
        self.session.mount('https://', adapter)

    @retry(max_retries=3, delay=1)
    def _request(self, method: str, path: str, **kwargs) -> Optional[Dict]:
        """
        统一请求方法，自动添加认证、超时、错误处理
        :param method: HTTP方法 GET/POST/PUT/DELETE
        :param path: API路径（自动拼接base_url）
        :param kwargs: 其他请求参数
        :return: 响应JSON数据，失败返回None
        """
        start_time = time.time() if self.timing_enabled else 0
        url = f"{self.base_url}/{path.lstrip('/')}"
        headers = kwargs.pop('headers', {})
        headers.update(self.headers)

        # 精简返回字段，只返回必要信息
        params = kwargs.pop('params', {})
        if 'fields' not in params and method.upper() == 'GET':
            params['fields'] = 'id,name,status,code'

        try:
            response = self.session.request(
                method=method,
                url=url,
                headers=headers,
                params=params,
                timeout=self.timeout,
                verify=False,
                **kwargs
            )
            response.raise_for_status()
            result = response.json()

            # 记录API耗时
            if self.timing_enabled:
                cost = (time.time() - start_time) * 1000
                self._timing_stats["api_requests"].append({
                    "method": method,
                    "path": path,
                    "cost_ms": round(cost, 2),
                    "status": "success"
                })

            # 统一处理响应格式
            if result.get('code') == 0 or result.get('success') is True:
                return result.get('data', result)
            else:
                logger.error(f"API请求失败: {result.get('msg', '未知错误')}")
                if self.timing_enabled:
                    self._timing_stats["api_requests"][-1]["status"] = "failed"
                return None
        except requests.exceptions.RequestException as e:
            if self.timing_enabled:
                cost = (time.time() - start_time) * 1000
                self._timing_stats["api_requests"].append({
                    "method": method,
                    "path": path,
                    "cost_ms": round(cost, 2),
                    "status": "error"
                })
            logger.error(f"请求异常: {str(e)}")
            raise

    # =============================================================================
    #                                核心操作方法
    # =============================================================================

    # -------------------------- 1. 启动工作流实例 --------------------------
    def start_workflow_instance(self, project_name: str, process_id: int, failure_strategy: str = "CONTINUE") -> Optional[int]:
        """
        手动启动工作流实例（任务执行），自动上线工作流
        :param project_name: 项目名称
        :param process_id: 工作流ID
        :param failure_strategy: 失败策略：CONTINUE/END/FAIL_OVER
        :return: 执行实例ID，失败返回None
        """
        # 先上线工作流，无论当前状态
        self.release_workflow(project_name, process_id, release_state=1)
        try:
            # 使用正确的API路径
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/executors/start-process-instance"

            form_data = {
                "processDefinitionId": process_id,
                "scheduleTime": "",
                "failureStrategy": failure_strategy,
                "warningType": "NONE",
                "warningGroupId": 0,
                "execType": "",
                "startNodeList": "",
                "taskDependType": "TASK_POST",
                "runMode": "RUN_MODE_SERIAL",
                "processInstancePriority": "MEDIUM",
                "receivers": "",
                "receiversCc": "",
                "workerGroup": "flink"
            }

            headers = self.headers.copy()
            headers["Content-Type"] = "application/x-www-form-urlencoded"
            headers["Origin"] = self.base_url

            resp = requests.post(
                url,
                headers=headers,
                data=form_data,
                verify=False,
                timeout=10
            )
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                # 只要 code == 0 就算启动成功，某些版本的DolphinScheduler返回 data: null
                instance_data = data.get('data')
                if instance_data and isinstance(instance_data, dict):
                    instance_id = instance_data.get('id')
                    if instance_id:
                        logger.info(f"✅ 工作流实例启动成功: ID={instance_id}")
                        return instance_id
                # data 为 null 或没有 id 也仍然是成功
                logger.info(f"✅ 工作流实例启动成功")
                return 0  # 返回 0 表示成功，区别于 None 表示失败
            elif "not online" in str(data.get('msg', '')) or "未上线" in str(data.get('msg', '')):
                logger.info(f"工作流未上线，正在自动上线: ID={process_id}")
                if self.release_workflow(project_name, process_id, release_state=1):
                    # 上线成功后重试启动
                    return self.start_workflow_instance(project_name, process_id, failure_strategy)
                else:
                    logger.error(f"工作流上线失败，无法启动")
                    return None
            else:
                logger.error(f"工作流实例启动失败: {data.get('msg', '未知错误')}")
                return None

        except requests.exceptions.RequestException as e:
            logger.error(f"调用启动工作流接口异常: {str(e)}", exc_info=True)
            return None
        except Exception as e:
            logger.error(f"解析启动工作流响应异常: {str(e)}", exc_info=True)
            return None

    # -------------------------- 2. 工作流上下线 --------------------------
    def release_workflow(self, project_name: str, process_id: int, release_state: int = 0) -> bool:
        """
        上线/下线工作流（任务下线使用release_state=0）
        :param project_name: 项目名称
        :param process_id: 工作流ID
        :param release_state: 1=上线，0=下线（默认改为下线）
        """
        try:
            # API路径需要项目名称，不是ID
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/process/release"

            form_data = {
                "processId": process_id,
                "releaseState": release_state
            }

            headers = self.headers.copy()
            headers["Content-Type"] = "application/x-www-form-urlencoded"

            resp = requests.post(
                url,
                headers=headers,
                data=form_data,
                verify=False,
                timeout=10
            )
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                state_desc = "上线" if release_state == 1 else "下线"
                logger.info(f"✅ 工作流 {state_desc} 成功: ID={process_id}")
                return True
            else:
                logger.error(f"工作流操作失败: {data.get('msg', '未知错误')}")
                return False
        except requests.exceptions.RequestException as e:
            logger.error(f"调用工作流操作接口异常: {str(e)}", exc_info=True)
            return False
        except Exception as e:
            logger.error(f"解析工作流操作响应异常: {str(e)}", exc_info=True)
            return False

    # -------------------------- 3. 任务上线 --------------------------
    def online_workflow(self, project_name: str, process_id_or_name: Union[int, str]) -> bool:
        """
        任务上线（封装 release_workflow 的上线方法）
        :param project_name: 项目名称
        :param process_id_or_name: 工作流ID或名称
        """
        # 如果传入的是名称，先查找工作流获取ID
        if isinstance(process_id_or_name, str):
            workflow = self.get_workflow_by_name(project_name, process_id_or_name)
            if not workflow:
                logger.error(f"未找到名为 {process_id_or_name} 的工作流")
                return False
            process_id = workflow['id']
        else:
            process_id = process_id_or_name
        return self.release_workflow(project_name, process_id, release_state=1)

    # -------------------------- 4. 任务下线 --------------------------
    def offline_workflow(self, project_name: str, process_id_or_name: Union[int, str]) -> bool:
        """
        任务下线（封装 release_workflow 的下线方法）
        :param project_name: 项目名称
        :param process_id_or_name: 工作流ID或名称
        """
        # 如果传入的是名称，先查找工作流获取ID
        if isinstance(process_id_or_name, str):
            workflow = self.get_workflow_by_name(project_name, process_id_or_name)
            if not workflow:
                logger.error(f"未找到名为 {process_id_or_name} 的工作流")
                return False
            process_id = workflow['id']
        else:
            process_id = process_id_or_name
        return self.release_workflow(project_name, process_id, release_state=0)

    # =============================================================================
    #                                定时调度管理
    # =============================================================================

    # -------------------------- 5. 根据调度ID查询调度信息 --------------------------
    def get_schedules_by_workflow_id(self, project_name: str, workflow_id: int) -> List[Dict]:
        """根据工作流ID查询所有调度信息"""
        try:
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/schedule/list-paging"

            params = {
                "processDefinitionId": workflow_id,
                "pageSize": 100,
                "pageNo": 1,
                "searchVal": ""
            }

            resp = requests.get(url, headers=self.headers, params=params, verify=False, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                return data.get('data', {}).get('totalList', [])
            return []
        except Exception as e:
            logger.error(f"查询工作流调度失败: {str(e)}")
            return []

    def get_schedule_by_id(self, project_name: str, schedule_id: int) -> Optional[Dict]:
        """根据调度ID查询调度信息 - 修复版本"""
        try:
            # 使用正确的API路径：通过list-paging获取全部调度，然后筛选
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/schedule/list-paging"

            # 设置足够大的pageSize确保获取所有调度
            params = {
                "pageSize": 1000,
                "pageNo": 1,
                "searchVal": ""
            }

            resp = requests.get(url, headers=self.headers, params=params, verify=False, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                total_list = data.get('data', {}).get('totalList', [])
                # 在列表中查找匹配ID的调度
                for schedule in total_list:
                    if schedule.get('id') == schedule_id:
                        return schedule
                
                logger.error(f"未找到ID为 {schedule_id} 的调度")
                return None
            else:
                logger.error(f"查询调度列表失败: {data.get('msg', '未知错误')}")
                return None
                
        except requests.exceptions.RequestException as e:
            logger.error(f"调用调度查询接口异常: {str(e)}", exc_info=True)
            return None
        except Exception as e:
            logger.error(f"解析调度查询响应异常: {str(e)}", exc_info=True)
            return None
    # -------------------------- 6. 根据工作流ID查询工作流信息 --------------------------
    def get_workflow_by_id(self, project_name: str, process_id: int) -> Optional[Dict]:
        """根据工作流ID查询工作流详细信息"""
        try:
            # 使用正确的API路径：通过list-paging获取全部工作流，然后筛选
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/process/list-paging"
            
            # 设置足够大的pageSize确保获取所有工作流
            params = {
                "pageSize": 1000,
                "pageNo": 1,
                "searchVal": "",
                "userId": ""
            }
            
            resp = requests.get(url, headers=self.headers, params=params, verify=False, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            
            if data.get('code') == 0:
                total_list = data.get('data', {}).get('totalList', [])
                # 在列表中查找匹配ID的工作流
                for workflow in total_list:
                    if workflow.get('id') == process_id:
                        return workflow
                
                logger.error(f"未找到ID为 {process_id} 的工作流")
                return None
            else:
                logger.error(f"查询工作流列表失败: {data.get('msg', '未知错误')}")
                return None
                
        except requests.exceptions.RequestException as e:
            logger.error(f"调用工作流查询接口异常: {str(e)}", exc_info=True)
            return None
        except Exception as e:
            logger.error(f"解析工作流查询响应异常: {str(e)}", exc_info=True)
            return None

    # -------------------------- 7. 定时任务上线 --------------------------
    def online_schedule(self, project_name: str, schedule_id: int, check_workflow_online: bool = False) -> bool:
        """
        上线定时调度（支持校验关联工作流是否已上线）
        :param project_name: 项目名称
        :param schedule_id: 调度ID
        :param check_workflow_online: 是否校验关联工作流是否已上线，默认关闭（创建后直接上线）
        """
        if check_workflow_online:
            # 查询调度对应的工作流ID
            schedule = self.get_schedule_by_id(project_name, schedule_id)
            if not schedule:
                logger.warning(f"未查询到调度信息，直接尝试上线: {schedule_id}")
            else:
                process_id = schedule.get('processDefinitionId')
                workflow = self.get_workflow_by_id(project_name, process_id)
                if workflow.get("releaseState") != "ONLINE":
                    logger.error(f"关联工作流未上线，当前状态：{workflow.get('releaseState')}")
                    return False

        try:
            # API路径需要项目名称，不是ID
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/schedule/online"

            form_data = {
                "id": schedule_id
            }

            headers = self.headers.copy()
            headers["Content-Type"] = "application/x-www-form-urlencoded"

            resp = requests.post(
                url,
                headers=headers,
                data=form_data,
                verify=False,
                timeout=10
            )
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                logger.info(f"✅ 定时调度上线成功: ID={schedule_id}")
                return True
            else:
                logger.error(f"定时调度上线失败: {data.get('msg', '未知错误')}")
                return False
        except requests.exceptions.RequestException as e:
            logger.error(f"调用定时上线接口异常: {str(e)}", exc_info=True)
            return False
        except Exception as e:
            logger.error(f"解析定时上线响应异常: {str(e)}", exc_info=True)
            return False

    # -------------------------- 5. 定时任务下线 --------------------------
    def offline_schedule(self, project_name: str, schedule_id: int) -> bool:
        """
        下线定时调度任务
        :param project_name: 项目名称
        :param schedule_id: 调度ID
        """
        try:
            # API路径需要项目名称，不是ID
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/schedule/offline"

            form_data = {
                "id": schedule_id
            }

            headers = self.headers.copy()
            headers["Content-Type"] = "application/x-www-form-urlencoded"

            resp = requests.post(
                url,
                headers=headers,
                data=form_data,
                verify=False,
                timeout=10
            )
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                logger.info(f"✅ 定时调度下线成功: ID={schedule_id}")
                return True
            else:
                logger.error(f"定时调度下线失败: {data.get('msg', '未知错误')}")
                return False
        except requests.exceptions.RequestException as e:
            logger.error(f"调用定时下线接口异常: {str(e)}", exc_info=True)
            return False
        except Exception as e:
            logger.error(f"解析定时下线响应异常: {str(e)}", exc_info=True)
            return False

    def delete_schedule(self, project_name: str, schedule_id: int) -> bool:
        """
        删除定时调度（删除前自动下线）
        :param project_name: 项目名称
        :param schedule_id: 调度ID
        """
        try:
            # 先下线调度
            self.offline_schedule(project_name, schedule_id)

            # 执行删除操作
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/schedule/delete"
            params = {
                "scheduleId": schedule_id
            }

            resp = requests.get(
                url,
                headers=self.headers,
                params=params,
                verify=False,
                timeout=10
            )
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                logger.info(f"✅ 定时调度删除成功: ID={schedule_id}")
                return True
            else:
                logger.error(f"定时调度删除失败: {data.get('msg', '未知错误')}")
                return False
        except requests.exceptions.RequestException as e:
            logger.error(f"调用定时删除接口异常: {str(e)}", exc_info=True)
            return False
        except Exception as e:
            logger.error(f"解析定时删除响应异常: {str(e)}", exc_info=True)
            return False

    # -------------------------- 6. 更新资源文件内容 --------------------------
    def update_resource_content(self, resource_id: int, content: str) -> bool:
        """
        更新资源文件内容
        :param resource_id: 资源文件ID
        :param content: 新的文件内容
        :return: 是否更新成功
        """
        try:
            url = f"{self.base_url}/dolphinscheduler/resources/update-content"
            data = {
                "id": resource_id,
                "content": content
            }

            resp = requests.post(
                url,
                headers=self.headers,
                data=data,
                verify=False,
                timeout=10
            )
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                logger.info(f"✅ 资源文件更新成功: ID={resource_id}")
                return True
            else:
                logger.error(f"资源文件更新失败: {data.get('msg', '未知错误')}")
                return False
        except requests.exceptions.RequestException as e:
            logger.error(f"调用资源更新接口异常: {str(e)}", exc_info=True)
            return False
        except Exception as e:
            logger.error(f"解析资源更新响应异常: {str(e)}", exc_info=True)
            return False

    def start_create_table_workflow(self, process_definition_id: int, worker_group: str = "flink") -> Optional[int]:
        """
        启动固定建表工作流
        :param process_definition_id: 建表工作流ID
        :param worker_group: Worker组，默认flink
        :return: 工作流实例ID，失败返回None
        """
        # 直接复用已有的启动工作流方法
        return self.start_workflow_instance("建表", process_definition_id)

    # -------------------------- 7. 查询所有项目（可筛选） --------------------------
    def list_projects(self, page_size: int = 200, page_no: int = 1, search_val: str = "") -> List[Dict]:
        """
        查询所有项目列表（支持分页和搜索筛选）
        :param page_size: 每页数量
        :param page_no: 页码
        :param search_val: 搜索关键词
        :return: 项目列表
        """
        try:
            url = f"{self.base_url}/dolphinscheduler/projects/list-paging"
            params = {"pageSize": page_size, "pageNo": page_no, "searchVal": search_val}

            resp = requests.get(url, headers=self.headers, params=params, verify=False, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                return data.get('data', {}).get('totalList', [])
            else:
                logger.error(f"查询项目失败: {data.get('msg', '未知错误')}")
                return []
        except requests.exceptions.RequestException as e:
            logger.error(f"调用项目列表接口异常: {str(e)}", exc_info=True)
            return []
        except Exception as e:
            logger.error(f"解析项目列表响应异常: {str(e)}", exc_info=True)
            return []

    # -------------------------- 7. 查询某项目所有工作流（可筛选） --------------------------
    def list_workflows(self, project_name: str, page_size: int = 200, page_no: int = 1, search_val: str = "") -> List[Dict]:
        """
        查询项目下所有工作流（支持分页和搜索筛选）
        :param project_name: 项目名称
        :param page_size: 每页数量
        :param page_no: 页码
        :param search_val: 搜索关键词
        :return: 工作流列表
        """
        try:
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/process/list-paging"
            params = {"pageSize": page_size, "pageNo": page_no, "searchVal": search_val, "userId": ""}

            resp = requests.get(
                url,
                headers=self.headers,
                params=params,
                verify=False,
                timeout=10
            )
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                return data.get('data', {}).get('totalList', [])
            else:
                logger.error(f"查询工作流失败: {data.get('msg', '未知错误')}")
                return []
        except requests.exceptions.RequestException as e:
            logger.error(f"调用工作流列表接口异常: {str(e)}", exc_info=True)
            return []
        except Exception as e:
            logger.error(f"解析工作流列表响应异常: {str(e)}", exc_info=True)
            return []

    # -------------------------- 8. 查询某工作流所有任务（可筛选） --------------------------
    def list_workflow_tasks(self, project_name: str, process_id: int) -> List[Dict]:
        """
        查询指定工作流的所有任务节点
        :param project_name: 项目名称
        :param process_id: 工作流ID
        :return: 任务节点列表
        """
        try:
            # 先查询工作流详情获取任务信息
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/process-definition/{process_id}"
            resp = requests.get(url, headers=self.headers, verify=False, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                process_data = data.get('data', {})
                # 新版API返回的任务结构
                if 'taskDefinitionList' in process_data:
                    return process_data.get('taskDefinitionList', [])
                # 旧版API返回的任务结构
                elif 'tasks' in process_data:
                    return process_data.get('tasks', [])
                else:
                    return []
            else:
                logger.error(f"查询工作流任务失败: {data.get('msg', '未知错误')}")
                return []
        except requests.exceptions.RequestException as e:
            logger.error(f"调用工作流任务列表接口异常: {str(e)}", exc_info=True)
            return []
        except Exception as e:
            logger.error(f"解析工作流任务列表响应异常: {str(e)}", exc_info=True)
            return []

    # -------------------------- 9. 查询某项目下所有工作流实例执行记录 --------------------------
    def list_all_workflow_instances(self, project_name: str, search_filters: Dict = None, limit: int = 50) -> List[Dict]:
        """
        查询某项目下所有工作流实例执行记录（支持筛选）
        :param project_name: 项目名称
        :param search_filters: 筛选条件字典（如{'stateType': 'SUCCESS', 'startDate': '2025-04-01'}）
        :param limit: 最多返回记录数，默认50，最大不超过50
        :return: 执行记录列表
        """
        try:
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/instance/list-paging"

            # 强制限制最大返回50条记录
            limit = min(limit, 50)

            # 设置默认分页参数
            params = {
                "pageSize": limit,
                "pageNo": 1,
                "searchVal": "",
                "host": "",
                "stateType": "",
                "startDate": "",
                "endDate": "",
                "executorName": ""
            }
            
            # 如果提供了筛选条件，则更新参数
            if search_filters:
                params.update(search_filters)

            resp = requests.get(url, headers=self.headers, params=params, verify=False, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                return data.get('data', {}).get('totalList', [])
            else:
                logger.error(f"查询工作流实例记录失败: {data.get('msg', '未知错误')}")
                return []
        except requests.exceptions.RequestException as e:
            logger.error(f"调用工作流实例记录接口异常: {str(e)}", exc_info=True)
            return []
        except Exception as e:
            logger.error(f"解析工作流实例记录响应异常: {str(e)}", exc_info=True)
            return []

    # -------------------------- 12. 查询某项目下所有任务实例执行记录 --------------------------
    def list_all_task_instances(self, project_name: str, search_filters: Dict = None, limit: int = 50) -> List[Dict]:
        """
        查询某项目下所有任务实例执行记录（支持筛选）
        :param project_name: 项目名称
        :param search_filters: 筛选条件字典（如{'stateType': 'SUCCESS', 'startDate': '2025-04-01'}）
        :param limit: 最多返回记录数，默认50，最大不超过50
        :return: 执行记录列表
        """
        try:
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/task-instance/list-paging"

            # 强制限制最大返回50条记录
            limit = min(limit, 50)

            # 设置默认分页参数
            params = {
                "pageSize": limit,
                "pageNo": 1,
                "searchVal": "",
                "processInstanceId": "",
                "host": "",
                "stateType": "",
                "startDate": "",
                "endDate": "",
                "executorName": ""
            }
            
            # 如果提供了筛选条件，则更新参数
            if search_filters:
                params.update(search_filters)

            resp = requests.get(url, headers=self.headers, params=params, verify=False, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                return data.get('data', {}).get('totalList', [])
            else:
                logger.error(f"查询任务实例记录失败: {data.get('msg', '未知错误')}")
                return []
        except requests.exceptions.RequestException as e:
            logger.error(f"调用任务实例记录接口异常: {str(e)}", exc_info=True)
            return []
        except Exception as e:
            logger.error(f"解析任务实例记录响应异常: {str(e)}", exc_info=True)
            return []

    # -------------------------- 13. 查询某项目下某工作流的执行实例历史情况 --------------------------
    def list_workflow_execution_history(self, project_name: str, workflow_name: str, search_filters: Dict = None, limit: int = 50) -> List[Dict]:
        """
        查询某项目下某工作流的执行实例历史情况（点查优化，直接通过名称搜索）
        :param project_name: 项目名称
        :param workflow_name: 工作流名称
        :param search_filters: 筛选条件字典（如{'stateType': 'SUCCESS', 'startDate': '2025-04-01'}）
        :param limit: 最多返回记录数，默认50，最大不超过50
        :return: 执行实例历史记录列表
        """
        try:
            # 直接使用搜索API查询，性能更高
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/process_instance/list-paging"

            # 强制限制最大返回50条记录
            limit = min(limit, 50)

            params = {
                "pageSize": limit,
                "pageNo": 1,
                "searchVal": workflow_name
            }
            if search_filters:
                params.update(search_filters)

            resp = requests.get(url, headers=self.headers, params=params, verify=False, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                instances = data.get('data', {}).get('totalList', [])[:limit]
                # 精确匹配名称，避免返回类似名称的记录
                return [inst for inst in instances if workflow_name in inst.get('name', '')]
            else:
                logger.error(f"查询工作流执行历史失败: {data.get('msg', '未知错误')}")
                return []
            if not process_id:
                logger.error(f"工作流 {workflow_name} 没有有效的ID")
                return []
            
            # 使用项目级查询接口，通过searchVal参数筛选特定工作流
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/instance/list-paging"
            
            # 设置默认参数
            params = {
                "pageSize": 100,
                "pageNo": 1,
                "searchVal": workflow_name,  # 直接使用工作流名称进行搜索
                "host": "",
                "stateType": "",
                "startDate": "",
                "endDate": "",
                "executorName": ""
            }
            
            # 如果提供了筛选条件，则更新参数
            if search_filters:
                params.update(search_filters)
            
            resp = requests.get(url, headers=self.headers, params=params, verify=False, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            
            if data.get('code') == 0:
                instances = data.get('data', {}).get('totalList', [])
                logger.info(f"✅ 查询到工作流 {workflow_name} 的 {len(instances)} 条执行历史记录")
                return instances
            else:
                logger.error(f"查询工作流执行历史失败: {data.get('msg', '未知错误')}")
                return []
                
        except requests.exceptions.RequestException as e:
            logger.error(f"调用工作流执行历史查询接口异常: {str(e)}", exc_info=True)
            return []
        except Exception as e:
            logger.error(f"解析工作流执行历史响应异常: {str(e)}", exc_info=True)
            return []

    # -------------------------- 14. 查询某项目下某任务的执行实例历史情况 --------------------------
    def list_task_execution_history(self, project_name: str, task_name: str, search_filters: Dict = None, limit: int = 50) -> List[Dict]:
        """
        查询某项目下某任务的执行实例历史情况
        :param project_name: 项目名称
        :param task_name: 任务名称
        :param search_filters: 筛选条件字典（如{'stateType': 'SUCCESS', 'startDate': '2025-04-01'}）
        :param limit: 最多返回记录数，默认50，最大不超过50
        :return: 任务执行实例历史记录列表
        """
        try:
            # 使用项目级任务实例查询接口，通过searchVal参数筛选特定任务
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/task-instance/list-paging"

            # 强制限制最大返回50条记录
            limit = min(limit, 50)

            # 设置默认参数
            params = {
                "pageSize": limit,
                "pageNo": 1,
                "searchVal": task_name,  # 直接使用任务名称进行搜索
                "processInstanceId": "",
                "host": "",
                "stateType": "",
                "startDate": "",
                "endDate": "",
                "executorName": ""
            }
            
            # 如果提供了筛选条件，则更新参数
            if search_filters:
                params.update(search_filters)
            
            resp = requests.get(url, headers=self.headers, params=params, verify=False, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            
            if data.get('code') == 0:
                instances = data.get('data', {}).get('totalList', [])
                logger.info(f"✅ 查询到任务 {task_name} 的 {len(instances)} 条执行历史记录")
                return instances
            else:
                logger.error(f"查询任务执行历史失败: {data.get('msg', '未知错误')}")
                return []
                
        except requests.exceptions.RequestException as e:
            logger.error(f"调用任务执行历史查询接口异常: {str(e)}", exc_info=True)
            return []
        except Exception as e:
            logger.error(f"解析任务执行历史响应异常: {str(e)}", exc_info=True)
            return []

    # -------------------------- 19. 创建项目 --------------------------
    def create_project(self, project_name: str, description: str = "") -> bool:
        """
        创建新项目
        :param project_name: 项目名称
        :param description: 项目描述
        :return: 是否创建成功
        """
        try:
            url = f"{self.base_url}/dolphinscheduler/projects/create"

            data = {
                "projectName": project_name,
                "description": description
            }

            headers = self.headers.copy()
            headers["Content-Type"] = "application/x-www-form-urlencoded"

            resp = requests.post(
                url,
                headers=headers,
                data=data,
                verify=False,
                timeout=10
            )
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                logger.info(f"✅ 项目创建成功: {project_name}")
                return True
            else:
                logger.error(f"项目创建失败: {data.get('msg', '未知错误')}")
                return False
        except requests.exceptions.RequestException as e:
            logger.error(f"调用创建项目接口异常: {str(e)}", exc_info=True)
            return False
        except Exception as e:
            logger.error(f"解析创建项目响应异常: {str(e)}", exc_info=True)
            return False

    # -------------------------- 20. 创建某项目工作流 --------------------------
    def create_workflow(self, project_name: str, workflow_name: str, tasks: List[Dict] = None, description: str = "") -> Optional[Dict]:
        """
        创建工作流
        :param project_name: 项目名称
        :param workflow_name: 工作流名称
        :param tasks: 任务节点列表，默认None时创建一个打印工作流名称的Shell任务
        :param description: 工作流描述
        :return: 工作流信息，失败返回None
        """
        # 获取项目信息
        project = self.get_project_by_name(project_name)
        # 如果未提供任务列表，创建默认的Shell打印任务
        if tasks is None:
            tasks = [self.create_shell_task(name=workflow_name, script=f"echo 'Workflow {workflow_name} started'")]
        if not project:
            logger.error(f"项目 {project_name} 不存在")
            return None

        try:
            # 构建任务位置
            locations = {}
            for i, task in enumerate(tasks):
                task_id = f"tasks-{i+10000}"
                task['id'] = task_id
                locations[task_id] = {
                    "name": task['name'],
                    "targetarr": "",
                    "nodenumber": str(i),
                    "x": 290 + i * 200,
                    "y": 320
                }

            # 构建processDefinitionJson
            process_def = {
                "globalParams": [],
                "tasks": tasks,
                "tenantId": 1,
                "timeout": 0
            }

            # 表单数据
            form_data = {
                "processDefinitionJson": json.dumps(process_def, ensure_ascii=False),
                "name": workflow_name,
                "description": description,
                "locations": json.dumps(locations, ensure_ascii=False),
                "connects": "[]"
            }

            # API路径
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/process/save"

            headers = self.headers.copy()
            headers["Content-Type"] = "application/x-www-form-urlencoded"

            resp = requests.post(
                url,
                headers=headers,
                data=form_data,
                verify=False,
                timeout=10
            )
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                # 创建成功后查询工作流信息
                workflow_info = self.get_workflow_by_name(project_name, workflow_name)
                logger.info(f"✅ 工作流创建成功: {workflow_name}")
                return workflow_info
            elif "名称重复" in str(data.get('msg', '')) or "已经存在" in str(data.get('msg', '')):
                logger.info(f"ℹ️  工作流 {workflow_name} 已存在")
                return self.get_workflow_by_name(project_name, workflow_name)
            else:
                logger.error(f"工作流创建失败: {data.get('msg', '未知错误')}")
                return None
        except requests.exceptions.RequestException as e:
            logger.error(f"调用创建工作流接口异常: {str(e)}", exc_info=True)
            return None
        except Exception as e:
            logger.error(f"解析创建工作流响应异常: {str(e)}", exc_info=True)
            return None

    # -------------------------- 21. 创建某项目某工作流任务 --------------------------
    def add_task_to_workflow(self, project_name: str, workflow_id: int, task: Dict, replace_all: bool = False) -> bool:
        """
        给已有工作流添加新的任务节点
        :param project_name: 项目名称
        :param workflow_id: 工作流ID
        :param task: 任务节点配置
        :param replace_all: 是否替换所有现有任务，默认False（追加）
        :return: 是否添加成功
        """
        try:
            # 先获取现有工作流的完整配置
            workflow = self.get_workflow_by_id(project_name, workflow_id)
            if not workflow:
                logger.error(f"未找到工作流: ID={workflow_id}")
                return False

            # 获取现有任务列表
            existing_tasks = [] if replace_all else workflow.get('tasks', [])
            # 添加新任务
            existing_tasks.append(task)

            # 重新构建工作流配置
            locations = {} if replace_all else workflow.get('locations', {})
            # 更新任务位置（自动分配新位置）
            task_count = len(existing_tasks)
            task_id = f"tasks-{task_count + 10000}"
            task['id'] = task_id
            locations[task_id] = {
                "name": task['name'],
                "targetarr": "",
                "nodenumber": str(task_count -1),
                "x": 290 + (task_count -1) * 200,
                "y": 320
            }

            process_def = {
                "globalParams": workflow.get('globalParams', []),
                "tasks": existing_tasks,
                "tenantId": workflow.get('tenantId', 1),
                "timeout": workflow.get('timeout', 0)
            }

            form_data = {
                "id": workflow.get('id'),
                "processDefinitionJson": json.dumps(process_def, ensure_ascii=False),
                "name": workflow.get('name'),
                "description": workflow.get('description', ""),
                "locations": json.dumps(locations, ensure_ascii=False),
                "connects": json.dumps([] if replace_all else workflow.get('connects', []))
            }

            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/process/update"
            headers = self.headers.copy()
            headers["Content-Type"] = "application/x-www-form-urlencoded"

            resp = requests.post(
                url,
                headers=headers,
                data=form_data,
                verify=False,
                timeout=10
            )
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                logger.info(f"✅ 成功向工作流添加任务: {task.get('name')}")
                return True
            else:
                logger.error(f"添加任务到工作流失败: {data.get('msg', '未知错误')}")
                return False
        except requests.exceptions.RequestException as e:
            logger.error(f"调用更新工作流接口异常: {str(e)}", exc_info=True)
            return False
        except Exception as e:
            logger.error(f"解析更新工作流响应异常: {str(e)}", exc_info=True)
            return False

    # -------------------------- 22. 创建定时任务 --------------------------
    def create_schedule(self, project_name: str, process_definition_id: int, cron: str,
                    start_time: str = "2026-01-01 00:00:00", end_time: str = "2126-12-31 23:59:59",
                    worker_group: str = "flink") -> Optional[int]:
        """
        创建定时调度，自动上线工作流
        :param project_name: 项目名称
        :param process_definition_id: 工作流ID
        :param cron: cron表达式，如 "0 0 1 * * ? *"
        :param start_time: 调度开始时间
        :param end_time: 调度结束时间
        :param worker_group: Worker组
        :return: 调度ID，失败返回None
        """
        # 先上线工作流，无论当前状态
        self.release_workflow(project_name, process_definition_id, release_state=1)
        try:
            # 1. 创建定时调度，API路径需要项目名称
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/schedule/create"
            schedule_config = {
                "startTime": start_time,
                "endTime": end_time,
                "crontab": cron
            }
            form_data = {
                "schedule": json.dumps(schedule_config, ensure_ascii=False),
                "failureStrategy": "CONTINUE",
                "warningType": "NONE",
                "processInstancePriority": "MEDIUM",
                "warningGroupId": 0,
                "receivers": "",
                "receiversCc": "",
                "workerGroup": worker_group,
                "processDefinitionId": process_definition_id
            }
            headers = self.headers.copy()
            headers["Content-Type"] = "application/x-www-form-urlencoded"

            resp = requests.post(url, headers=headers, data=form_data, verify=False, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            if data.get('code') == 0:
                # 2. 查询刚创建的调度（通过 processDefinitionId）
                list_url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/schedule/list-paging"
                params = {
                    "processDefinitionId": process_definition_id,
                    "pageNo": 1,
                    "pageSize": 10,
                    "searchVal": ""
                }
                list_resp = requests.get(
                    list_url,
                    headers=self.headers,
                    params=params,
                    verify=False,
                    timeout=10
                )
                list_resp.raise_for_status()
                list_data = list_resp.json()

                if list_data.get('code') == 0:
                    total_list = list_data.get('data', {}).get('totalList', [])
                    if total_list:
                        schedule_id = total_list[0]['id']
                        logger.info(f"✅ 定时调度创建成功，schedule_id: {schedule_id}")
                        return schedule_id
                    else:
                        logger.error("❌ 创建成功但未查到对应的调度记录")
                        return None
                else:
                    logger.error(f"查询调度列表失败: {list_data.get('msg', '未知错误')}")
                    return None
            else:
                logger.error(f"定时调度创建失败: {data.get('msg', '未知错误')}")
                return None

        except requests.exceptions.RequestException as e:
            # 检查是否是工作流未上线的错误
            if "not online" in str(e).lower() or "未上线" in str(e):
                logger.info(f"工作流未上线，正在自动上线: ID={process_definition_id}")
                if self.release_workflow(project_name, process_definition_id, release_state=1):
                    # 上线成功后重试创建调度
                    return self.create_schedule(project_name, process_definition_id, cron, start_time, end_time, worker_group)
            logger.error(f"创建或查询定时调度异常: {str(e)}", exc_info=True)
            return None
        except Exception as e:
            logger.error(f"创建或查询定时调度异常: {str(e)}", exc_info=True)
            return None

    # -------------------------- 辅助工具方法 --------------------------
    @lru_cache(maxsize=128)
    def get_project_by_name(self, project_name: str) -> Optional[Dict]:
        """根据项目名称获取项目信息"""
        projects = self.list_projects()
        for proj in projects:
            if proj.get('name') == project_name:
                return proj
        logger.error(f"未找到项目: {project_name}")
        return None

    def get_workflow_by_name(self, project_name: str, workflow_name: str) -> Optional[Dict]:
        """根据工作流名称查询完整工作流信息（使用搜索API优化性能，不缓存，避免脏数据）"""
        try:
            url = f"{self.base_url}/dolphinscheduler/projects/{project_name}/process/list-paging"
            params = {
                "pageSize": 10,
                "pageNo": 1,
                "searchVal": workflow_name
            }
            headers = self.headers.copy()
            resp = requests.get(url, headers=headers, params=params, verify=False, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            if data.get('code') == 0:
                workflows = data.get('data', {}).get('totalList', [])
                for wf in workflows:
                    if wf.get('name') == workflow_name:
                        logger.info(f"找到工作流: {workflow_name} (ID: {wf.get('id')})")
                        return wf
            logger.error(f"未找到工作流: {workflow_name}")
            return None
        except Exception as e:
            logger.error(f"查询工作流异常: {str(e)}")
            return None

    @lru_cache(maxsize=64)
    def get_tenant_id(self, tenant_name: str = "default") -> Optional[int]:
        """
        获取租户ID（缓存5分钟）
        :param tenant_name: 租户名称，默认default
        """
        try:
            tenants = self._request("GET", "/dolphinscheduler/tenant/list")
            if tenants:
                for tenant in tenants:
                    if tenant.get('tenantName') == tenant_name:
                        return tenant.get('id')
            logger.error(f"未找到租户: {tenant_name}")
            return None
        except Exception as e:
            logger.error(f"获取租户ID失败: {e}")
            return None

    @lru_cache(maxsize=32)
    def list_worker_groups(self, project_name: str) -> List[Dict]:
        """
        获取项目下的Worker组列表（缓存5分钟）
        :param project_name: 项目名称
        """
        try:
            project = self.get_project_by_name(project_name)
            if not project:
                return []
            worker_groups = self._request("GET", f"/dolphinscheduler/projects/{project['id']}/worker-groups")
            return worker_groups if worker_groups else []
        except Exception as e:
            logger.error(f"获取Worker组列表失败: {e}")
            return []

    def create_datax_task(self, name: str, json_config: str, pre_tasks: List[str] = None,
                         worker_group: str = "flink") -> Dict:
        """
        创建DataX任务节点
        :param name: 任务名称
        :param json_config: DataX配置JSON字符串
        :param pre_tasks: 前置任务名称列表
        :param worker_group: Worker组，默认flink
        """
        # 压缩JSON格式，和UI提交一致
        try:
            compact_json = json.dumps(json.loads(json_config), separators=(',', ':'))
        except Exception as e:
            logger.warning(f"JSON压缩失败，使用原始配置: {str(e)}")
            compact_json = json_config

        return {
            "type": "DATAX",
            "name": name,
            "params": {
                "customConfig": 1,
                "json": compact_json,
                "localParams": []
            },
            "description": "",
            "timeout": {
                "strategy": "",
                "interval": None,
                "enable": False
            },
            "runFlag": "NORMAL",
            "conditionResult": {
                "successNode": [""],
                "failedNode": [""]
            },
            "dependence": {},
            "maxRetryTimes": "3",
            "retryInterval": "3",
            "taskInstancePriority": "MEDIUM",
            "workerGroup": worker_group,
            "preTasks": pre_tasks or []
        }

    def create_shell_task(self, name: str, script: str, pre_tasks: List[str] = None,
                         worker_group: str = "flink") -> Dict:
        """
        创建Shell任务节点
        :param name: 任务名称
        :param script: Shell脚本内容
        :param pre_tasks: 前置任务名称列表
        :param worker_group: Worker组，默认flink
        """
        return {
            "type": "SHELL",
            "name": name,
            "params": {
                "rawScript": script,
                "localParams": []
            },
            "description": "",
            "timeout": {
                "strategy": "",
                "interval": None,
                "enable": False
            },
            "runFlag": "NORMAL",
            "conditionResult": {
                "successNode": [""],
                "failedNode": [""]
            },
            "dependence": {},
            "maxRetryTimes": "3",
            "retryInterval": "3",
            "taskInstancePriority": "MEDIUM",
            "workerGroup": worker_group,
            "preTasks": pre_tasks or []
        }

    # -------------------------- 数据同步功能（从sync-data技能合并） --------------------------
    def get_dbid(self, dbname: str) -> Optional[int]:
        """
        根据数据库名称获取数据库ID（调用DBA平台接口）
        :param dbname: 数据库名称或ID
        """
        # 如果输入已经是数字，直接返回
        if str(dbname).isdigit():
            return int(dbname)

        url = "http://dba.corp.shiqiao.com/face.html"
        params = {
            "faceid": "iehrmf4labkgpcyin0q1983us5",
            "token": "nqm1lp4ew59cir"
        }
        data = {
            "dbname": dbname
        }

        try:
            response = requests.post(
                url,
                params=params,
                data=data,
                headers={'Content-Type': 'application/x-www-form-urlencoded'}
            )

            if response.status_code == 200:
                dbinfo_list = ast.literal_eval(json.loads(response.text)['data']['dbinfo'])
                return dbinfo_list[0]['dbid']
            else:
                logger.error(f"获取dbid失败，状态码: {response.status_code}，响应: {response.text}")
                return None
        except requests.exceptions.RequestException as e:
            logger.error(f"调用DBA平台接口异常: {e}")
            return None

    def db2hive(self, dbid: int, tablename: str, output_dir: str = "/Users/lbc/Public/www/code/db2hive/") -> Optional[Dict]:
        """
        生成Hive建表SQL和DataX同步JSON配置（调用DBA平台接口）
        :param dbid: 源数据库ID
        :param tablename: 要同步的表名
        :param output_dir: 生成文件的保存目录
        :return: 返回生成的文件路径信息 {"sql_path": "...", "json_path": "..."}
        """
        # 确保输出目录存在
        os.makedirs(output_dir, exist_ok=True)

        try:
            response = requests.post(
                f"https://dba.corp.shiqiao.com/face.html?faceid=ixm83noh1ga4qucpf0ybki5rwt&token=tp6jq5mfr0kaou&dbid={dbid}&tablename={tablename}"
            )
            response.raise_for_status()
            result = response.json()

            json_url = result['data']['jsonurl']
            sql_url = result['data']['sqlurl']

            # 下载并处理SQL文件
            sql_content = requests.get(sql_url).text
            sqlstr_list = sql_content.split('\n')
            sql_list = []
            # 在SQL开头添加use语句
            sql_list.append("use lion_dw_ods;")
            for i in sqlstr_list:
                if 'DROP' in i.upper():
                    continue
                if 'FORMAT SERDE' in i.upper():
                    break
                sql_list.append(i)

            sql_path = os.path.join(output_dir, f"{tablename}.sql")
            with open(sql_path, "w", encoding="utf-8") as f:
                f.write('\n'.join(sql_list))
            logger.info(f"SQL文件已保存：{sql_path} (已自动添加use lion_dw_ods;)")

            # 下载JSON配置文件
            json_content = requests.get(json_url).text
            json_path = os.path.join(output_dir, f"{tablename}.json")
            with open(json_path, "w", encoding="utf-8") as f:
                f.write(json_content)
            logger.info(f"JSON配置文件已保存：{json_path}")

            return {
                "sql_path": sql_path,
                "sql_content": '\n'.join(sql_list),
                "json_path": json_path,
                "json_content": json_content
            }

        except Exception as e:
            logger.error(f"生成同步配置失败: {e}")
            return None

    def deploy_data_sync_task(
        self,
        dbname: str,
        tablelist: Union[str, List[str]],
        project_name: str,
        cron: str = "0 0 4 * * ? *",
        worker_group: str = "flink",
        output_dir: str = "/Users/lbc/Public/www/code/db2hive/",
        concurrency: int = 3,
        workflow_name_prefix: str = "",
        task_name_prefix: str = ""
    ) -> Dict:
        """
        一键部署数据同步任务（从数据库同步到Hive）
        :param dbname: 源数据库名称或ID
        :param tablelist: 要同步的表名列表，逗号分隔字符串或列表
        :param project_name: DolphinScheduler项目名称（必填，无默认值）
        :param cron: 定时调度cron表达式，默认每天凌晨4点
        :param worker_group: Worker组，默认flink
        :param output_dir: 配置文件保存目录
        :param concurrency: 并发数，默认3
        :param workflow_name_prefix: 工作流名称前缀，为空默认使用表名作为工作流名称
        :param task_name_prefix: 任务名称前缀，为空默认使用表名作为任务名称
        :return: 部署结果信息
        """
        """
        一键部署数据同步任务（从数据库同步到Hive）
        :param dbname: 源数据库名称或ID
        :param tablelist: 要同步的表名列表，逗号分隔字符串或列表
        :param project_name: DolphinScheduler项目名称
        :param cron: 定时调度cron表达式，默认每天凌晨4点
        :param worker_group: Worker组，默认flink
        :param output_dir: 配置文件保存目录
        :return: 部署结果信息
        """
        # 处理表名列表
        if isinstance(tablelist, str):
            tablelist = [t.strip() for t in tablelist.split(",")]

        # 启动耗时统计
        if self.timing_enabled:
            self._timing_stats["start_time"] = time.time()

        # 前置校验
        logger.info("开始执行前置校验...")
        # 1. 校验表名列表非空
        tablelist = [t for t in tablelist if t]
        if not tablelist:
            return {"success": False, "error": "表名列表为空"}

        # 2. 校验项目存在
        project = self.get_project_by_name(project_name)
        if not project:
            return {"success": False, "error": f"项目不存在: {project_name}"}

        # 3. 获取dbid
        dbid = self.get_dbid(dbname)
        if not dbid:
            return {"success": False, "error": f"无法获取数据库ID: {dbname}"}

        # 4. 校验API连通性
        try:
            # 尝试请求项目列表验证连通性
            self.list_projects()
        except Exception as e:
            return {"success": False, "error": f"DolphinScheduler API 连接失败: {str(e)}"}

        results = {
            "success": True,
            "dbid": dbid,
            "project_name": project_name,
            "cron": cron,
            "tables": [],
            "success_count": 0,
            "failed_count": 0,
            "skipped_count": 0,
            "total_count": len(tablelist)
        }

        # 单表处理：建表阶段（串行执行）
        def process_table_create_table(tablename: str) -> Dict:
            """处理单表的建表阶段，串行执行避免资源冲突"""
            start_time = time.time() if self.timing_enabled else 0
            logger.info(f"[建表阶段] 开始处理表: {tablename}")
            result = {
                "tablename": tablename,
                "status": "pending",
                "config": None,
                "workflow_name": "",
                "task_name": ""
            }

            try:
                # 生成工作流名称和任务名称
                workflow_name = f"{workflow_name_prefix}{tablename}" if workflow_name_prefix else tablename
                task_name = f"{task_name_prefix}{tablename}_同步任务" if task_name_prefix else f"{tablename}_同步任务"
                result["workflow_name"] = workflow_name
                result["task_name"] = task_name

                # 先检查工作流是否已经存在
                existing_workflow = self.get_workflow_by_name(project_name, workflow_name)
                if existing_workflow:
                    result["status"] = "skipped"
                    result["error"] = "工作流已存在，可能之前已同步过"
                    logger.warning(f"[{tablename}] 跳过处理：工作流 {workflow_name} 已存在 (ID: {existing_workflow['id']})")
                    return result

                # 步骤1: 查询DBA元数据生成配置
                logger.info(f"[{tablename}] 步骤1/4: 从DBA平台查询元数据生成同步配置")
                config = self.db2hive(dbid, tablename, output_dir)
                if not config:
                    result["status"] = "failed"
                    result["error"] = "DBA元数据查询失败，表不存在或权限不足"
                    logger.warning(f"[{tablename}] 跳过处理：{result['error']}，请确认表名是否正确")
                    return result
                result["config"] = config

                # 步骤2: 更新建表SQL资源文件
                logger.info(f"[{tablename}] 步骤2/4: 更新建表SQL资源文件")
                CREATE_TABLE_RESOURCE_ID = 1659
                CREATE_TABLE_WORKFLOW_ID = 13385
                sql_with_db = f"use lion_dw_ods;\n{config['sql_content']}"

                update_success = self.update_resource_content(CREATE_TABLE_RESOURCE_ID, sql_with_db)
                if not update_success:
                    result["status"] = "failed"
                    result["error"] = "更新建表资源文件失败"
                    logger.error(f"[{tablename}] 步骤2失败：{result['error']}")
                    return result

                # 步骤3: 启动建表工作流
                logger.info(f"[{tablename}] 步骤3/4: 启动固定建表工作流 (ID: {CREATE_TABLE_WORKFLOW_ID})")
                ct_instance_id = self.start_create_table_workflow(CREATE_TABLE_WORKFLOW_ID, worker_group)
                if ct_instance_id is None:
                    result["status"] = "failed"
                    result["error"] = "启动建表工作流失败"
                    logger.error(f"[{tablename}] 步骤3失败：{result['error']}")
                    return result

                # 步骤4: 等待建表完成
                logger.info(f"[{tablename}] 步骤4/4: 等待建表工作流执行完成")
                max_wait = 300
                wait_interval = 5
                waited = 0
                ct_success = False
                while waited < max_wait:
                    instances = self.list_all_workflow_instances("建表", search_filters={"pageSize": 10, "pageNo": 1})
                    if instances:
                        for instance in instances:
                            if instance.get('processDefinitionId') == CREATE_TABLE_WORKFLOW_ID:
                                state = instance.get('state')
                                if state == 'SUCCESS':
                                    ct_success = True
                                    break
                                elif state in ['FAILURE', 'STOP', 'PAUSE']:
                                    result["status"] = "failed"
                                    result["error"] = f"建表工作流执行失败，状态: {state}"
                                    logger.error(f"[{tablename}] 步骤4失败：{result['error']}")
                                    return result
                        if ct_success:
                            break
                    time.sleep(wait_interval)
                    waited += wait_interval

                if not ct_success:
                    result["status"] = "failed"
                    result["error"] = "建表工作流执行超时"
                    logger.error(f"[{tablename}] 步骤4失败：{result['error']}")
                    return result

                logger.info(f"[{tablename}] ✅ 建表阶段完成")
                result["status"] = "create_success"
                result["create_table_workflow_id"] = CREATE_TABLE_WORKFLOW_ID
                result["create_table_workflow_url"] = f"{self.base_url}/dolphinscheduler/ui/#/projects/建表/process-definition/{CREATE_TABLE_WORKFLOW_ID}/detail"

            except Exception as e:
                result["status"] = "failed"
                result["error"] = f"建表阶段异常: {str(e)}"
                logger.error(f"处理表 {tablename} 建表失败: {str(e)}", exc_info=True)

            if self.timing_enabled:
                cost = (time.time() - start_time) * 1000
                result["create_cost_ms"] = round(cost, 2)

            return result

        # 单表处理：同步任务部署阶段（并行执行）
        def process_table_deploy_sync(table_info: Dict) -> Dict:
            """处理单表的同步任务部署阶段，建表成功后并行执行"""
            start_time = time.time() if self.timing_enabled else 0
            tablename = table_info["tablename"]
            config = table_info["config"]
            workflow_name = table_info["workflow_name"]
            task_name = table_info["task_name"]

            logger.info(f"[部署阶段] 开始处理表: {tablename}")
            table_result = table_info.copy()

            try:
                # ==================== 步骤1: 创建DataX同步任务节点 ====================
                logger.info(f"[{tablename}] 步骤1/4: 创建DataX同步任务节点")
                datax_task = self.create_datax_task(
                    name=task_name,
                    json_config=config["json_content"],
                    worker_group=worker_group
                )
                if not datax_task:
                    table_result["status"] = "failed"
                    table_result["error"] = "创建DataX任务节点失败"
                    logger.error(f"[{tablename}] 步骤1失败：{table_result['error']}")
                    return table_result

                # ==================== 步骤2: 创建同步工作流 ====================
                logger.info(f"[{tablename}] 步骤2/4: 创建同步工作流")
                workflow_info = self.create_workflow(
                    project_name=project_name,
                    workflow_name=workflow_name,
                    tasks=[datax_task],
                    description=f"自动同步 {tablename} 表到Hive"
                )
                if not workflow_info:
                    table_result["status"] = "failed"
                    table_result["error"] = "创建工作流失败"
                    logger.error(f"[{tablename}] 步骤2失败：{table_result['error']}")
                    return table_result
                workflow_id = workflow_info['id']

                # ==================== 步骤3: 上线工作流 ====================
                logger.info(f"[{tablename}] 步骤3/4: 上线工作流")
                online_success = self.online_workflow(project_name, workflow_id)
                if not online_success:
                    table_result["status"] = "failed"
                    table_result["error"] = "工作流上线失败，请检查权限配置"
                    logger.error(f"[{tablename}] 步骤3失败：{table_result['error']}")
                    return table_result

                # ==================== 步骤4: 创建并上线定时调度（可选） ====================
                schedule_id = None
                if cron:
                    logger.info(f"[{tablename}] 步骤4/4: 创建定时调度并上线")
                    schedule_id = self.create_schedule(
                        project_name=project_name,
                        process_definition_id=workflow_id,
                        cron=cron
                    )
                    if not schedule_id:
                        table_result["status"] = "failed"
                        table_result["error"] = "创建定时调度失败"
                        logger.error(f"[{tablename}] 步骤4失败：{table_result['error']}")
                        return table_result

                    schedule_online_success = self.online_schedule(project_name, schedule_id)
                    if not schedule_online_success:
                        table_result["status"] = "failed"
                        table_result["error"] = "定时调度上线失败"
                        logger.error(f"[{tablename}] 步骤4失败：{table_result['error']}")
                        return table_result

                # 全部步骤成功
                table_result["status"] = "success"
                table_result["workflow_id"] = workflow_id
                table_result["schedule_id"] = schedule_id
                table_result["workflow_url"] = f"{self.base_url}/dolphinscheduler/ui/#/projects/{project_name}/process-definition/{workflow_id}/detail"
                logger.info(f"[{tablename}] ✅ 同步任务部署完成")

            except Exception as e:
                table_result["status"] = "failed"
                table_result["error"] = f"部署阶段异常: {str(e)}"
                logger.error(f"处理表 {tablename} 部署失败: {str(e)}", exc_info=True)

            if self.timing_enabled:
                cost = (time.time() - start_time) * 1000
                table_result["deploy_cost_ms"] = round(cost, 2)
                table_result["total_cost_ms"] = table_result["create_cost_ms"] + table_result["deploy_cost_ms"]
                self._timing_stats["table_processing"].append({
                    "tablename": tablename,
                    "create_cost_ms": table_result["create_cost_ms"],
                    "deploy_cost_ms": table_result["deploy_cost_ms"],
                    "total_cost_ms": table_result["total_cost_ms"],
                    "status": table_result["status"]
                })

            return table_result

        # ==================== 第一阶段：串行建表（避免资源冲突） ====================
        logger.info(f"===== 第一阶段：开始串行建表，共 {len(tablelist)} 个表 =====")
        create_table_results = []
        for index, tablename in enumerate(tablelist, 1):
            logger.info(f"建表进度: {index}/{len(tablelist)} - 处理表: {tablename}")
            result = process_table_create_table(tablename)
            create_table_results.append(result)

            # 统计建表阶段结果
            if result["status"] == "create_success":
                logger.info(f"[{tablename}] 建表成功，进入后续部署阶段")
            elif result["status"] == "skipped":
                results["skipped_count"] += 1
                results["tables"].append(result)
                logger.info(f"[{tablename}] 跳过处理")
            else:
                results["failed_count"] += 1
                results["tables"].append(result)
                logger.error(f"[{tablename}] 建表失败: {result['error']}")

            # 每个表处理完成后间隔2秒，避免请求太快导致资源冲突
            if index < len(tablelist):
                time.sleep(2)

        # 筛选出建表成功的表，进入部署阶段
        tables_to_deploy = [r for r in create_table_results if r["status"] == "create_success"]
        logger.info(f"===== 建表阶段完成：成功 {len(tables_to_deploy)} 个，失败 {results['failed_count']} 个，跳过 {results['skipped_count']} 个 =====")

        # ==================== 第二阶段：并行部署同步任务（提升效率） ====================
        if tables_to_deploy:
            logger.info(f"===== 第二阶段：开始并行部署同步任务，共 {len(tables_to_deploy)} 个表，并发数: {concurrency} =====")
            with ThreadPoolExecutor(max_workers=concurrency) as executor:
                futures = {executor.submit(process_table_deploy_sync, table_info): table_info["tablename"] for table_info in tables_to_deploy}

                # 收集部署结果
                completed = 0
                for future in as_completed(futures):
                    tablename = futures[future]
                    try:
                        table_result = future.result()
                        if table_result["status"] == "success":
                            results["success_count"] += 1
                        else:
                            results["failed_count"] += 1
                        results["tables"].append(table_result)

                        completed += 1
                        progress = (completed / len(tables_to_deploy)) * 100
                        logger.info(f"部署进度: {completed}/{len(tables_to_deploy)} ({progress:.1f}%) - 表 {tablename} 部署完成: {table_result['status']}")
                    except Exception as e:
                        logger.error(f"部署表 {tablename} 时发生未捕获异常: {e}")
                        results["failed_count"] += 1
                        results["tables"].append({
                            "tablename": tablename,
                            "status": "failed",
                            "error": str(e)
                        })
        else:
            logger.info("没有需要部署的同步任务")

        # 统计总耗时
        if self.timing_enabled:
            total_cost = (time.time() - self._timing_stats["start_time"]) * 1000
            self._timing_stats["total_time_ms"] = round(total_cost, 2)
            results["timing_report"] = self._timing_stats

        logger.info(f"数据同步任务部署完成：成功 {results['success_count']} 个，失败 {results['failed_count']} 个，总计 {results['total_count']} 个")

        # 自动执行新部署成功的同步任务
        if results['success_count'] > 0:
            logger.info(f"===== 开始自动执行新部署的同步任务，共 {results['success_count']} 个 =====")
            for table in results['tables']:
                if table['status'] == 'success':
                    tablename = table['tablename']
                    workflow_id = table['workflow_id']
                    logger.info(f"[{tablename}] 正在启动同步工作流 (ID: {workflow_id})")
                    # 每个任务启动前固定延迟10秒，确保Hive建表操作完全完成，目录已创建
                    time.sleep(10)
                    instance_id = self.start_workflow_instance(project_name, workflow_id)
                    if instance_id is not None:
                        logger.info(f"[{tablename}] ✅ 同步工作流启动成功，实例ID: {instance_id}")
                    else:
                        logger.error(f"[{tablename}] ❌ 同步工作流启动失败")
            logger.info("===== 自动执行任务完成 =====")
        logger.info("💡 提示：您可以点击上面的工作流地址查看任务实际执行情况")

        return results

    def deploy_datax_workflow_with_schedule(
        self,
        project_name: str,
        workflow_name: str,
        datax_json_config: str,
        cron: str,
        description: str = "",
        worker_group: str = "flink",
        start_time: str = "2025-01-01 00:00:00",
        end_time: str = "2030-12-31 23:59:59"
    ) -> bool:
        """
        一键部署并上线 DataX 工作流 + 定时调度
        """
        # 1. 确保项目存在
        if not self.get_project_by_name(project_name):
            logger.info(f"项目 [{project_name}] 不存在，正在创建...")
            if not self.create_project(project_name, description or f"Auto-created for {workflow_name}"):
                return False

        # 2. 获取或创建工作流
        wf = self.get_workflow_by_name(project_name, workflow_name)
        if wf:
            process_id = wf['id']
            logger.info(f"复用现有工作流: {workflow_name} (ID: {process_id})")
        else:
            task = self.create_datax_task(name=workflow_name, json_config=datax_json_config, worker_group=worker_group)
            wf = self.create_workflow(project_name, workflow_name, tasks=[task], description=description)
            if not wf:
                return False
            process_id = wf['id']

        # 3. 上线工作流
        if not self.release_workflow(project_name, process_id, release_state=1):
            return False

        # 4. 创建并上线定时调度
        schedule_id = self.create_schedule(
            project_name=project_name,
            process_definition_id=process_id,
            cron=cron,
            start_time=start_time,
            end_time=end_time,
            worker_group=worker_group
        )
        if not schedule_id:
            logger.error("❌ 无法获取 schedule_id，跳过上线")
            return False

        if self.online_schedule(project_name, schedule_id):
            logger.info("🎉 一键部署完成：DataX 工作流与定时调度均已上线！")
            return True
        else:
            logger.error("❌ 定时调度上线失败")
            return False

if __name__ == "__main__":
    # 命令行入口
    if len(sys.argv) < 2:
        print("用法: python dolphinscheduler_manager.py <命令> [参数...]")
        print()
        print("可用命令:")
        print("  list-projects                  - 列出所有项目")
        print("  create-project <名称> [描述]   - 创建新项目")
        print("  list-workflows <项目名称>      - 列出项目下所有工作流")
        print("  start-workflow <项目> <工作流>  - 启动工作流（支持名称或ID）")
        print("  list-workflow-history <项目> <工作流> [状态]  - 查询工作流执行历史")
        print("  list-task-history <项目> <任务> [状态]        - 查询任务执行历史")
        print("  list-all-workflow-instances <项目> [状态]     - 查询项目所有工作流实例")
        print("  list-all-task-instances <项目> [状态]         - 查询项目所有任务实例")
        print("  list-workflow-tasks <项目> <工作流ID或名称>   - 查询工作流的所有任务节点")
        print("  sync-data [选项] <数据库> <表名列表> <项目名称> [cron表达式]  - 一键部署数据同步任务到Hive")
        print("    选项:")
        print("      --background          后台执行，不阻塞当前会话")
        print("      --concurrency <num>   并发数，默认3")
        print("      --enable-timing       开启耗时统计（测试阶段使用）")
        print("      --workflow-prefix <前缀>  工作流名称前缀，为空默认使用表名")
        print("      --task-prefix <前缀>      任务名称前缀，为空默认使用表名_同步任务")
        print("  batch-offline-workflow <项目> <工作流ID列表>   - 批量下线工作流，ID用逗号分隔")
        print("  batch-online-workflow <项目> <工作流ID列表>    - 批量上线工作流，ID用逗号分隔")
        print("  batch-start-workflow <项目> <工作流ID列表>     - 批量启动工作流，ID用逗号分隔")
        print("  restart-failed-etl <项目>                     - 重启项目下所有失败的ETL工作流")
        print("  pause-test-workflows <项目>                    - 暂停项目下所有测试类工作流")
        print("  online-workflow <项目> <工作流ID或名称>        - 上线单个工作流")
        print("  offline-workflow <项目> <工作流ID或名称>       - 下线单个工作流")
        print("  create-schedule <项目> <工作流ID或名称> <cron表达式>  - 为工作流创建定时调度")
        print("  online-schedule <项目> <调度ID>                - 上线定时调度")
        print("  offline-schedule <项目> <调度ID>               - 下线定时调度")
        print("  delete-schedule <项目> <调度ID>                - 删除定时调度（自动先下线）")
        print("  list-schedules <项目> <工作流ID或名称>         - 查询工作流的所有调度任务")
        print("  update-resource-content <资源ID> <内容>        - 更新资源文件内容")
        print()
        print("状态筛选可选值: SUCCESS, FAILURE, RUNNING, STOP, PAUSE")
        print()
        print("示例:")
        print("  python dolphinscheduler_manager.py start-workflow 数据项目 用户表同步")
        print("  python dolphinscheduler_manager.py list-workflow-history 数据项目 用户表同步 SUCCESS")
        print("  python dolphinscheduler_manager.py sync-data 93 RC_APP_MGT_D 数据同步项目 \"0 0 4 * * ? *\"")
        print("  python dolphinscheduler_manager.py sync-data 数据库名 user,order,goods 数据同步项目")
        sys.exit(1)

    command = sys.argv[1]
    # 从环境变量读取配置，或使用默认值
    base_url = os.getenv("DOLPHINSCHEDULER_BASE_URL", "http://olds.bigdata.shiqiao.com")
    token = os.getenv("DOLPHINSCHEDULER_TOKEN", "0d133fb5d24e3c3d63b14c759c198a7b")
    client = DolphinSchedulerAPIClient(base_url=base_url, token=token)

    if command == "list-projects":
        # 检查是否需要输出JSON
        output_json = len(sys.argv) > 2 and sys.argv[2] == "--json"
        projects = client.list_projects()

        if output_json:
            print(json.dumps(projects, ensure_ascii=False, indent=2))
        else:
            # 输出表格
            headers = ["项目ID", "项目名称", "创建者", "工作流数量", "运行中实例数", "创建时间"]
            fields = ["id", "name", "userName", "defCount", "instRunningCount", "createTime"]

            # 预处理时间
            processed_projects = []
            for p in projects:
                processed = p.copy()
                processed['createTime'] = processed['createTime'].replace('T', ' ')[:10] if processed.get('createTime') else ''
                processed_projects.append(processed)

            print_table(processed_projects, headers, fields)
            print(f"\n总项目数: {len(projects)}")
    elif command == "create-project":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py create-project <项目名称> [描述]")
            sys.exit(1)
        name = sys.argv[2]
        desc = sys.argv[3] if len(sys.argv) >3 else ""
        client.create_project(name, desc)
    elif command == "list-workflows":
        if len(sys.argv) <3:
            print("用法: python dolphinscheduler_manager.py list-workflows <项目名称> [--json]")
            print("--json: 输出原始JSON格式")
            sys.exit(1)
        project_name = sys.argv[2]
        output_json = len(sys.argv) > 3 and sys.argv[3] == "--json"
        workflows = client.list_workflows(project_name)

        if output_json:
            print(json.dumps(workflows, ensure_ascii=False, indent=2))
        else:
            # 预处理数据
            processed = []
            for wf in workflows:
                item = wf.copy()
                item['releaseState'] = '已上线' if item.get('releaseState') == 1 else '已下线'
                item['updateTime'] = item['updateTime'].replace('T', ' ')[:16] if item.get('updateTime') else ''
                processed.append(item)

            # 输出表格
            headers = ["工作流ID", "工作流名称", "状态", "版本", "更新时间", "创建者"]
            fields = ["id", "name", "releaseState", "version", "updateTime", "userName"]
            print_table(processed, headers, fields)
    elif command == "list-workflow-history":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py list-workflow-history <项目名称> <工作流名称> [状态筛选] [--json] [--limit <数量>]")
            print("状态筛选可选值: SUCCESS, FAILURE, RUNNING 等")
            print("--json: 输出原始JSON格式")
            print("--limit: 最多返回记录数，默认50，最大不超过50")
            sys.exit(1)
        project_name = sys.argv[2]
        workflow_name = sys.argv[3]
        search_filters = {}
        output_json = False
        limit = 50

        # 解析参数
        i = 4
        while i < len(sys.argv):
            if sys.argv[i] == "--json":
                output_json = True
                i += 1
            elif sys.argv[i] == "--limit" and i + 1 < len(sys.argv):
                try:
                    limit = int(sys.argv[i+1])
                    i += 2
                except ValueError:
                    print("错误: --limit 参数必须后跟整数")
                    sys.exit(1)
            else:
                search_filters["stateType"] = sys.argv[i]
                i += 1

        instances = client.list_workflow_execution_history(project_name, workflow_name, search_filters, limit)

        if output_json:
            print(json.dumps(instances, ensure_ascii=False, indent=2))
        else:
            # 预处理数据
            processed_instances = []
            for inst in instances:
                processed = inst.copy()
                processed['startTime'] = processed['startTime'].replace('T', ' ')[:19] if processed.get('startTime') else ''
                processed['endTime'] = processed['endTime'].replace('T', ' ')[:19] if processed.get('endTime') else ''
                processed['commandType'] = '手动执行' if processed.get('commandType') == 'START_PROCESS' else '定时调度' if processed.get('commandType') == 'SCHEDULER' else processed.get('commandType', '')
                processed_instances.append(processed)

            # 输出表格
            headers = ["实例ID", "状态", "执行类型", "执行者", "开始时间", "结束时间", "耗时(秒)"]
            fields = ["id", "state", "commandType", "executorName", "startTime", "endTime", "duration"]
            print_table(processed_instances, headers, fields)
    elif command == "list-task-history":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py list-task-history <项目名称> <任务名称> [状态筛选] [--json] [--limit <数量>]")
            print("状态筛选可选值: SUCCESS, FAILURE, RUNNING 等")
            print("--json: 输出原始JSON格式")
            print("--limit: 最多返回记录数，默认50，最大不超过50")
            sys.exit(1)
        project_name = sys.argv[2]
        task_name = sys.argv[3]
        search_filters = {}
        output_json = False
        limit = 50

        # 解析参数
        i = 4
        while i < len(sys.argv):
            if sys.argv[i] == "--json":
                output_json = True
                i += 1
            elif sys.argv[i] == "--limit" and i + 1 < len(sys.argv):
                try:
                    limit = int(sys.argv[i+1])
                    i += 2
                except ValueError:
                    print("错误: --limit 参数必须后跟整数")
                    sys.exit(1)
            else:
                search_filters["stateType"] = sys.argv[i]
                i += 1

        instances = client.list_task_execution_history(project_name, task_name, search_filters, limit)

        if output_json:
            print(json.dumps(instances, ensure_ascii=False, indent=2))
        else:
            # 预处理数据
            processed_instances = []
            for inst in instances:
                processed = inst.copy()
                processed['startTime'] = processed['startTime'].replace('T', ' ')[:19] if processed.get('startTime') else ''
                processed['endTime'] = processed['endTime'].replace('T', ' ')[:19] if processed.get('endTime') else ''
                processed['taskType'] = processed.get('taskType', '')
                processed_instances.append(processed)

            # 输出表格，显示更丰富的明细
            headers = ["任务实例ID", "任务名称", "状态", "任务类型", "重试次数", "工作流实例ID", "开始时间", "结束时间", "耗时(秒)", "执行主机", "Worker组"]
            fields = ["id", "name", "state", "taskType", "retryTimes", "processInstanceId", "startTime", "endTime", "duration", "host", "workerGroup"]
            print_table(processed_instances, headers, fields)
    elif command == "list-all-workflow-instances":
        if len(sys.argv) < 3:
            print("用法: python dolphinscheduler_manager.py list-all-workflow-instances <项目名称> [状态筛选] [--json] [--limit <数量>]")
            print("状态筛选可选值: SUCCESS, FAILURE, RUNNING 等")
            print("--json: 输出原始JSON格式")
            print("--limit: 最多返回记录数，默认50，最大不超过50")
            sys.exit(1)
        project_name = sys.argv[2]
        search_filters = {}
        output_json = False
        limit = 50
        i = 3
        while i < len(sys.argv):
            if sys.argv[i] == "--json":
                output_json = True
                i += 1
            elif sys.argv[i] == "--limit" and i + 1 < len(sys.argv):
                try:
                    limit = int(sys.argv[i+1])
                    i += 2
                except ValueError:
                    print("错误: --limit 参数必须后跟整数")
                    sys.exit(1)
            else:
                search_filters["stateType"] = sys.argv[i]
                i += 1

        instances = client.list_all_workflow_instances(project_name, search_filters, limit)

        if output_json:
            print(json.dumps(instances, ensure_ascii=False, indent=2))
        else:
            # 预处理数据
            processed_instances = []
            for inst in instances:
                processed = inst.copy()
                processed['startTime'] = processed['startTime'].replace('T', ' ')[:19] if processed.get('startTime') else ''
                processed['endTime'] = processed['endTime'].replace('T', ' ')[:19] if processed.get('endTime') else ''
                processed['commandType'] = '手动执行' if processed.get('commandType') == 'START_PROCESS' else '定时调度' if processed.get('commandType') == 'SCHEDULER' else processed.get('commandType', '')
                processed['name'] = processed.get('name', '').split('-')[0] if '-' in processed.get('name', '') else processed.get('name', '')
                processed_instances.append(processed)

            # 输出表格
            headers = ["实例ID", "工作流名称", "状态", "执行类型", "执行者", "开始时间", "结束时间", "耗时(秒)"]
            fields = ["id", "name", "state", "commandType", "executorName", "startTime", "endTime", "duration"]
            print_table(processed_instances, headers, fields)
    elif command == "list-all-task-instances":
        if len(sys.argv) < 3:
            print("用法: python dolphinscheduler_manager.py list-all-task-instances <项目名称> [状态筛选] [--json] [--limit <数量>]")
            print("状态筛选可选值: SUCCESS, FAILURE, RUNNING 等")
            print("--json: 输出原始JSON格式")
            print("--limit: 最多返回记录数，默认50，最大不超过50")
            sys.exit(1)
        project_name = sys.argv[2]
        search_filters = {}
        output_json = False
        limit = 50

        # 解析参数
        i = 3
        while i < len(sys.argv):
            if sys.argv[i] == "--json":
                output_json = True
                i += 1
            elif sys.argv[i] == "--limit" and i + 1 < len(sys.argv):
                try:
                    limit = int(sys.argv[i+1])
                    i += 2
                except ValueError:
                    print("错误: --limit 参数必须后跟整数")
                    sys.exit(1)
            else:
                search_filters["stateType"] = sys.argv[i]
                i += 1

        instances = client.list_all_task_instances(project_name, search_filters, limit)

        if output_json:
            print(json.dumps(instances, ensure_ascii=False, indent=2))
        else:
            # 预处理数据
            processed_instances = []
            for inst in instances:
                processed = inst.copy()
                processed['startTime'] = processed['startTime'].replace('T', ' ')[:19] if processed.get('startTime') else ''
                processed['endTime'] = processed['endTime'].replace('T', ' ')[:19] if processed.get('endTime') else ''
                processed['taskType'] = processed.get('taskType', '')
                # 截断过长的任务名称
                if len(processed.get('name', '')) > 20:
                    processed['name'] = processed['name'][:17] + '...'
                processed_instances.append(processed)

            # 输出表格，显示更丰富的明细
            headers = ["任务实例ID", "任务名称", "状态", "任务类型", "重试次数", "开始时间", "结束时间", "耗时(秒)", "执行主机", "Worker组"]
            fields = ["id", "name", "state", "taskType", "retryTimes", "startTime", "endTime", "duration", "host", "workerGroup"]
            print_table(processed_instances, headers, fields)
    elif command == "list-workflow-tasks":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py list-workflow-tasks <项目名称> <工作流ID或名称> [--json]")
            print("--json: 输出原始JSON格式")
            sys.exit(1)
        project_name = sys.argv[2]
        workflow_identifier = sys.argv[3]
        output_json = len(sys.argv) > 4 and sys.argv[4] == "--json"

        # 先查询工作流信息
        workflow = client.get_workflow_by_name(project_name, workflow_identifier)
        if not workflow:
            try:
                process_id = int(workflow_identifier)
                workflow = client.get_workflow_by_id(project_name, process_id)
            except ValueError:
                pass

        if not workflow:
            print(f"错误: 未找到工作流 {workflow_identifier} 在项目 {project_name} 中")
            sys.exit(1)

        tasks = client.list_workflow_tasks(project_name, workflow.get('id'))

        if output_json:
            print(json.dumps(tasks, ensure_ascii=False, indent=2))
        else:
            # 预处理数据
            processed_tasks = []
            for task in tasks:
                processed = task.copy()
                processed['taskType'] = processed.get('taskType', '')
                processed['flag'] = '启用' if processed.get('flag') == 'YES' else '禁用'
                processed_tasks.append(processed)

            # 输出表格
            headers = ["任务ID", "任务名称", "任务类型", "状态", "重试次数", "超时时间", "Worker组"]
            fields = ["id", "name", "taskType", "flag", "maxRetryTimes", "timeout", "workerGroup"]
            print_table(processed_tasks, headers, fields)
            print(f"\n工作流: {workflow.get('name')} (ID: {workflow.get('id')}), 共 {len(tasks)} 个任务节点")
    elif command == "start-workflow":
        if len(sys.argv) <4:
            print("用法: python dolphinscheduler_manager.py start-workflow <项目名称> <工作流ID或名称>")
            print("或: python dolphinscheduler_manager.py start-workflow --project <项目名称> --workflow <工作流名称>")
            sys.exit(1)

        # 解析参数
        project_name = None
        workflow_identifier = None

        # 处理带选项的参数
        if len(sys.argv) >=5 and sys.argv[2] == "--project" and sys.argv[4] == "--workflow":
            project_name = sys.argv[3]
            workflow_identifier = sys.argv[5]
        else:
            # 处理位置参数
            project_name = sys.argv[2]
            workflow_identifier = sys.argv[3]

        # 先查询工作流信息
        workflow = client.get_workflow_by_name(project_name, workflow_identifier)
        if not workflow:
            # 如果不是按名称查询，尝试按ID查询
            try:
                process_id = int(workflow_identifier)
                workflow = client.get_workflow_by_id(project_name, process_id)
            except ValueError:
                pass

        if not workflow:
            print(f"错误: 未找到工作流 {workflow_identifier} 在项目 {project_name} 中")
            sys.exit(1)

        process_id = workflow.get('id')
        print(f"找到工作流: {workflow.get('name')} (ID: {process_id})")

        # 启动工作流
        instance_id = client.start_workflow_instance(project_name, process_id)
        if instance_id is not None:
            if instance_id == 0:
                print(f"✅ 工作流启动成功")
            else:
                print(f"✅ 工作流启动成功，实例ID: {instance_id}")
        else:
            print(f"❌ 工作流启动失败")
            sys.exit(1)
    elif command == "sync-data":
        # 解析参数
        parser = argparse.ArgumentParser(add_help=False)
        parser.add_argument("--background", action="store_true", help="后台执行任务")
        parser.add_argument("--concurrency", type=int, default=3, help="并发数，默认3")
        parser.add_argument("--enable-timing", action="store_true", help="开启耗时统计（测试阶段使用）")
        parser.add_argument("--workflow-prefix", default="", help="工作流名称前缀，为空默认使用表名")
        parser.add_argument("--task-prefix", default="", help="任务名称前缀，为空默认使用表名_同步任务")
        parser.add_argument("dbname", help="数据库ID或名称")
        parser.add_argument("tablelist", help="表名列表，逗号分隔")
        parser.add_argument("project_name", help="项目名称")
        parser.add_argument("cron", nargs="?", default="0 0 4 * * ? *", help="cron表达式，默认每天凌晨4点")

        # 解析参数（去掉command参数）
        args = parser.parse_args(sys.argv[2:])

        dbname = args.dbname
        tablelist = args.tablelist
        project_name = args.project_name
        cron = args.cron
        concurrency = args.concurrency
        background = args.background
        enable_timing = args.enable_timing
        workflow_prefix = args.workflow_prefix
        task_prefix = args.task_prefix

        print(f"🚀 开始部署数据同步任务:")
        print(f"  源数据库: {dbname}")
        print(f"  同步表名: {tablelist}")
        print(f"  项目名称: {project_name}")
        print(f"  定时规则: {cron}")
        print(f"  并发数: {concurrency}")
        print(f"  后台执行: {'是' if background else '否'}")
        print()

        if background:
            # 生成任务ID
            task_id = str(uuid.uuid4())[:8]
            # 后台执行
            import subprocess
            log_file = f"/tmp/dolphinscheduler_sync_{task_id}.log"
            # 构造命令（去掉--background参数）
            cmd = [
                sys.executable, __file__, "sync-data",
                dbname, tablelist, project_name, cron,
                "--concurrency", str(concurrency),
                "--workflow-prefix", workflow_prefix,
                "--task-prefix", task_prefix
            ]
            if enable_timing:
                cmd.append("--enable-timing")
            # 启动后台进程
            with open(log_file, "w") as f:
                subprocess.Popen(cmd, stdout=f, stderr=f, start_new_session=True)

            print(f"📋 任务已提交到后台执行，任务ID: {task_id}")
            print(f"📝 日志文件: {log_file}")
            print(f"🔍 执行完成后会自动通知结果，请继续其他操作。")
            sys.exit(0)

        # 重新实例化client，传入耗时统计开关
        client = DolphinSchedulerAPIClient(
            base_url=base_url,
            token=token,
            timing_enabled=enable_timing
        )
        result = client.deploy_data_sync_task(
            dbname, tablelist, project_name, cron,
            concurrency=concurrency,
            workflow_name_prefix=workflow_prefix,
            task_name_prefix=task_prefix
        )

        print("\n📊 部署结果:")
        print(f"  数据库ID: {result.get('dbid', 'N/A')}")
        print(f"  成功数量: {result.get('success_count', 0)}")
        print(f"  失败数量: {result.get('failed_count', 0)}")
        print(f"  跳过数量: {result.get('skipped_count', 0)}")
        print()

        skipped_tables = []
        for table in result.get('tables', []):
            if table['status'] == 'success':
                status = "✅ 成功"
                print(f"  {status} {table['tablename']}")
                print(f"      SQL文件: {table.get('sql_path', 'N/A')}")
                print(f"      JSON配置: {table.get('json_path', 'N/A')}")
                print(f"      工作流ID: {table.get('workflow_id', 'N/A')}")
                print(f"      工作流地址: {table.get('workflow_url', 'N/A')}")
            elif table['status'] == 'skipped':
                status = "⚠️  跳过"
                skipped_tables.append(table['tablename'])
                print(f"  {status} {table['tablename']}")
                print(f"      原因: {table.get('error', '未知错误')}")
            else:
                status = "❌ 失败"
                print(f"  {status} {table['tablename']}")
                print(f"      错误信息: {table.get('error', '未知错误')}")
            print()

        # 提示用户检查跳过的表
        if skipped_tables:
            print("⚠️  重要提示:")
            print(f"  以下表因为工作流已存在被跳过，请确认是否之前已经同步过:")
            for table in skipped_tables:
                print(f"    - {table}")
            print()

        # 输出耗时报告（如果开启）
        if enable_timing and 'timing_report' in result:
            timing = result['timing_report']
            print("\n⏱️  耗时统计报告:")
            print(f"  总耗时: {timing['total_time_ms']/1000:.2f} 秒")
            print(f"  API请求总数: {len(timing['api_requests'])} 次")
            if timing['api_requests']:
                avg_api = sum(req['cost_ms'] for req in timing['api_requests']) / len(timing['api_requests'])
                max_api = max(req['cost_ms'] for req in timing['api_requests'])
                print(f"  API平均耗时: {avg_api:.2f} ms")
                print(f"  API最大耗时: {max_api:.2f} ms")
            print(f"  表处理总数: {len(timing['table_processing'])} 个")
            if timing['table_processing']:
                avg_table = sum(tbl['cost_ms'] for tbl in timing['table_processing']) / len(timing['table_processing'])
                max_table = max(tbl['cost_ms'] for tbl in timing['table_processing'])
                print(f"  单表平均耗时: {avg_table:.2f} ms")
                print(f"  单表最大耗时: {max_table:.2f} ms")
            print()

        if result.get('failed_count', 0) > 0:
            sys.exit(1)

    elif command == "batch-offline-workflow":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py batch-offline-workflow <项目名称> <工作流ID列表>")
            print("工作流ID用逗号分隔，例如: 123,456,789")
            sys.exit(1)
        project_name = sys.argv[2]
        workflow_ids = [int(id.strip()) for id in sys.argv[3].split(",") if id.strip().isdigit()]
        print(f"📋 批量下线 {len(workflow_ids)} 个工作流...")
        success = 0
        for wf_id in workflow_ids:
            if client.offline_workflow(project_name, wf_id):
                success += 1
                print(f"  ✅ 工作流 {wf_id} 下线成功")
            else:
                print(f"  ❌ 工作流 {wf_id} 下线失败")
        print(f"\n✅ 完成：成功 {success} 个，失败 {len(workflow_ids) - success} 个")

    elif command == "batch-online-workflow":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py batch-online-workflow <项目名称> <工作流ID列表>")
            print("工作流ID用逗号分隔，例如: 123,456,789")
            sys.exit(1)
        project_name = sys.argv[2]
        workflow_ids = [int(id.strip()) for id in sys.argv[3].split(",") if id.strip().isdigit()]
        print(f"📋 批量上线 {len(workflow_ids)} 个工作流...")
        success = 0
        for wf_id in workflow_ids:
            if client.online_workflow(project_name, wf_id):
                success += 1
                print(f"  ✅ 工作流 {wf_id} 上线成功")
            else:
                print(f"  ❌ 工作流 {wf_id} 上线失败")
        print(f"\n✅ 完成：成功 {success} 个，失败 {len(workflow_ids) - success} 个")

    elif command == "batch-start-workflow":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py batch-start-workflow <项目名称> <工作流ID列表>")
            print("工作流ID用逗号分隔，例如: 123,456,789")
            sys.exit(1)
        project_name = sys.argv[2]
        workflow_ids = [int(id.strip()) for id in sys.argv[3].split(",") if id.strip().isdigit()]
        print(f"📋 批量启动 {len(workflow_ids)} 个工作流...")
        success = 0
        for wf_id in workflow_ids:
            instance_id = client.start_workflow_instance(project_name, wf_id)
            if instance_id:
                success += 1
                print(f"  ✅ 工作流 {wf_id} 启动成功，实例ID: {instance_id}")
            else:
                print(f"  ❌ 工作流 {wf_id} 启动失败")
        print(f"\n✅ 完成：成功 {success} 个，失败 {len(workflow_ids) - success} 个")

    elif command == "restart-failed-etl":
        if len(sys.argv) < 3:
            print("用法: python dolphinscheduler_manager.py restart-failed-etl <项目名称>")
            sys.exit(1)
        project_name = sys.argv[2]
        print(f"🔍 查找项目 {project_name} 下所有失败的ETL工作流...")
        # 查询所有失败的工作流实例
        failed_instances = client.list_all_workflow_instances(project_name, search_filters={"stateType": "FAILURE"})
        if not failed_instances:
            print("✅ 没有找到失败的工作流实例")
            sys.exit(0)
        # 去重获取工作流ID
        failed_wf_ids = list({inst.get('processDefinitionId') for inst in failed_instances if inst.get('processDefinitionId')})
        print(f"📋 找到 {len(failed_wf_ids)} 个失败的工作流，开始重启...")
        success = 0
        for wf_id in failed_wf_ids:
            instance_id = client.start_workflow_instance(project_name, wf_id)
            if instance_id:
                success += 1
                print(f"  ✅ 工作流 {wf_id} 重启成功，实例ID: {instance_id}")
            else:
                print(f"  ❌ 工作流 {wf_id} 重启失败")
        print(f"\n✅ 完成：成功重启 {success} 个，失败 {len(failed_wf_ids) - success} 个")

    elif command == "pause-test-workflows":
        if len(sys.argv) < 3:
            print("用法: python dolphinscheduler_manager.py pause-test-workflows <项目名称>")
            sys.exit(1)
        project_name = sys.argv[2]
        print(f"🔍 查找项目 {project_name} 下所有测试类工作流...")
        workflows = client.list_workflows(project_name)
        # 匹配名称包含test/测试/debug/调试的工作流
        test_wfs = [wf for wf in workflows if any(key in wf.get('name', '').lower() for key in ['test', '测试', 'debug', '调试', 'temp'])]
        if not test_wfs:
            print("✅ 没有找到测试类工作流")
            sys.exit(0)
        print(f"📋 找到 {len(test_wfs)} 个测试工作流，开始下线...")
        success = 0
        for wf in test_wfs:
            if client.offline_workflow(project_name, wf['id']):
                success += 1
                print(f"  ✅ 工作流 {wf['name']} (ID: {wf['id']}) 下线成功")
            else:
                print(f"  ❌ 工作流 {wf['name']} (ID: {wf['id']}) 下线失败")
        print(f"\n✅ 完成：成功下线 {success} 个，失败 {len(test_wfs) - success} 个")
    elif command == "online-workflow":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py online-workflow <项目名称> <工作流ID或名称>")
            sys.exit(1)
        project_name = sys.argv[2]
        workflow_identifier = sys.argv[3]

        # 尝试解析为ID，如果是数字则直接使用，否则按名称查找
        try:
            workflow_id = int(workflow_identifier)
        except ValueError:
            # 按名称查找工作流
            workflow = client.get_workflow_by_name(project_name, workflow_identifier)
            if not workflow:
                print(f"❌ 未找到工作流: {workflow_identifier}")
                sys.exit(1)
            workflow_id = workflow['id']

        if client.online_workflow(project_name, workflow_id):
            print(f"✅ 工作流上线成功 (ID: {workflow_id})")
        else:
            print(f"❌ 工作流上线失败 (ID: {workflow_id})")
            sys.exit(1)
    elif command == "offline-workflow":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py offline-workflow <项目名称> <工作流ID或名称>")
            sys.exit(1)
        project_name = sys.argv[2]
        workflow_identifier = sys.argv[3]

        # 尝试解析为ID，如果是数字则直接使用，否则按名称查找
        try:
            workflow_id = int(workflow_identifier)
        except ValueError:
            # 按名称查找工作流
            workflow = client.get_workflow_by_name(project_name, workflow_identifier)
            if not workflow:
                print(f"❌ 未找到工作流: {workflow_identifier}")
                sys.exit(1)
            workflow_id = workflow['id']

        if client.offline_workflow(project_name, workflow_id):
            print(f"✅ 工作流下线成功 (ID: {workflow_id})")
        else:
            print(f"❌ 工作流下线失败 (ID: {workflow_id})")
            sys.exit(1)
    elif command == "create-schedule":
        if len(sys.argv) < 5:
            print("用法: python dolphinscheduler_manager.py create-schedule <项目名称> <工作流ID或名称> <cron表达式>")
            print("示例: python dolphinscheduler_manager.py create-schedule whm 大模型测试 \"0 0 1 * * ? *\"")
            sys.exit(1)
        project_name = sys.argv[2]
        workflow_identifier = sys.argv[3]
        cron = sys.argv[4]

        # 尝试解析为ID，如果是数字则直接使用，否则按名称查找
        try:
            workflow_id = int(workflow_identifier)
        except ValueError:
            # 按名称查找工作流
            workflow = client.get_workflow_by_name(project_name, workflow_identifier)
            if not workflow:
                print(f"❌ 未找到工作流: {workflow_identifier}")
                sys.exit(1)
            workflow_id = workflow['id']

        schedule_id = client.create_schedule(project_name, workflow_id, cron)
        if schedule_id:
            print(f"✅ 定时任务创建成功 (ID: {schedule_id})")
            # 自动上线定时任务
            if client.online_schedule(project_name, schedule_id):
                print(f"✅ 定时任务已自动上线，将按 cron 表达式 {cron} 执行")
            else:
                print(f"⚠️  定时任务创建成功，但上线失败，请手动上线")
        else:
            print(f"❌ 定时任务创建失败")
            sys.exit(1)
    elif command == "online-schedule":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py online-schedule <项目名称> <调度ID>")
            sys.exit(1)
        project_name = sys.argv[2]
        schedule_id = int(sys.argv[3])

        if client.online_schedule(project_name, schedule_id):
            print(f"✅ 定时任务上线成功 (ID: {schedule_id})")
        else:
            print(f"❌ 定时任务上线失败 (ID: {schedule_id})")
            sys.exit(1)
    elif command == "offline-schedule":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py offline-schedule <项目名称> <调度ID>")
            sys.exit(1)
        project_name = sys.argv[2]
        schedule_id = int(sys.argv[3])

        if client.offline_schedule(project_name, schedule_id):
            print(f"✅ 定时任务下线成功 (ID: {schedule_id})")
        else:
            print(f"❌ 定时任务下线失败 (ID: {schedule_id})")
            sys.exit(1)
    elif command == "delete-schedule":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py delete-schedule <项目名称> <调度ID>")
            sys.exit(1)
        project_name = sys.argv[2]
        schedule_id = int(sys.argv[3])

        if client.delete_schedule(project_name, schedule_id):
            print(f"✅ 定时任务删除成功 (ID: {schedule_id})")
        else:
            print(f"❌ 定时任务删除失败 (ID: {schedule_id})")
            sys.exit(1)
    elif command == "list-schedules":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py list-schedules <项目名称> <工作流ID或名称>")
            sys.exit(1)
        project_name = sys.argv[2]
        workflow_identifier = sys.argv[3]

        # 尝试解析为ID，如果是数字则直接使用，否则按名称查找
        try:
            workflow_id = int(workflow_identifier)
        except ValueError:
            # 按名称查找工作流
            workflow = client.get_workflow_by_name(project_name, workflow_identifier)
            if not workflow:
                print(f"❌ 未找到工作流: {workflow_identifier}")
                sys.exit(1)
            workflow_id = workflow['id']

        schedules = client.get_schedules_by_workflow_id(project_name, workflow_id)
        if not schedules:
            print("ℹ️  该工作流暂无调度任务")
            sys.exit(0)

        # 预处理数据
        processed = []
        for s in schedules:
            item = s.copy()
            item['status'] = '已上线' if item.get('releaseState') == 'ONLINE' else '已下线'
            item['createTime'] = item['createTime'].replace('T', ' ')[:16] if item.get('createTime') else ''
            processed.append(item)

        # 输出表格
        headers = ["调度ID", "cron表达式", "状态", "创建时间", "创建者"]
        fields = ["id", "crontab", "status", "createTime", "userName"]
        print_table(processed, headers, fields)
    elif command == "update-resource-content":
        if len(sys.argv) < 4:
            print("用法: python dolphinscheduler_manager.py update-resource-content <资源ID> <内容>")
            print("示例: python dolphinscheduler_manager.py update-resource-content 1659 \"select 1+2+3\"")
            sys.exit(1)
        resource_id = int(sys.argv[2])
        content = sys.argv[3]

        success = client.update_resource_content(resource_id, content)
        if success:
            print(f"✅ 资源文件ID={resource_id}更新成功")
        else:
            print(f"❌ 资源文件ID={resource_id}更新失败")
            sys.exit(1)
    else:
        print(f"未知命令: {command}")
        print()
        print("可用命令:")
        print("  list-projects")
        print("  create-project")
        print("  list-workflows")
        print("  start-workflow")
        print("  list-workflow-history")
        print("  list-task-history")
        print("  list-all-workflow-instances")
        print("  list-all-task-instances")
        print()
        sys.exit(1)