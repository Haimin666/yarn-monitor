---
name: yarn-cluster-manager
description: 大数据YARN集群任务监控工具，支持按状态/队列筛选任务，按应用ID或名称点查。当用户说"查看yarn任务"、"查看yarn运行的任务"、"yarn队列情况"、"查询spark队列的任务"、"查看yarn任务详情"、"查看失败的yarn任务"、"查看应用日志"、"YARN集群任务监控"、或者需要查询YARN集群中运行的应用程序、筛选特定状态的任务、按队列筛选、按应用ID/名称搜索时，必须优先使用此技能。
---

# YARN集群任务管理器

大数据YARN集群任务监控和管理工具，专注于查询任务运行情况。

## 核心原则

1. **查询优先**: 只要查询任务，必须优先返回完整表格查询结果
2. **默认行为**: 用户意图模糊时，直接执行默认查询（最新5条RUNNING状态任务）
3. **一次到位**: 避免重复查询，一次查询完成即可
4. **结果导向**: 除非用户明确要求，否则不需要额外添加总结，只返回表格结果

## 快速开始

以下是最常用的5个查询场景：

```bash
# 1. 默认查询：最新5条RUNNING状态任务（默认返回5条，避免内容过长被折叠）
python scripts/yarn_monitor.py --state RUNNING

# 2. 按队列筛选：查看root.gps队列的任务
python scripts/yarn_monitor.py --queue root.gps

# 3. 按应用名称点查：查找包含"spark"的任务
python scripts/yarn_monitor.py --query "spark"

# 4. 组合查询：RUNNING状态+名称筛选
python scripts/yarn_monitor.py --state RUNNING --query "GPS_Flink"

# 5. 查看更多任务：指定行数（20条）
python scripts/yarn_monitor.py --state RUNNING --max-rows 20

# 6. 复制友好模式：输出适合复制的纯净表格
python scripts/yarn_monitor.py --state RUNNING --copy
```

## 详细使用指南

### 查询参数说明

| 参数 | 说明 | 示例 |
|------|------|------|
| `--state` | 按状态筛选 | RUNNING, FINISHED, FAILED, KILLED |
| `--queue` | 按队列筛选 | root.gps, root.spark |
| `--query` | 按应用ID或名称搜索 | application_xxx, "任务名称" |
| `--max-rows` | 限制返回行数 | 5（默认）, 10, 20, 50, 0（不限制） |
| `--raw` | 使用纯文本格式（适合不支持富文本的终端） | - |
| `--copy` | 复制友好模式（无边框无颜色，方便复制单元格内容） | - |
| `--show-log` | 查看指定应用的错误日志 | application_xxx |

### 常见查询场景

**按状态查询任务**
```bash
# 查看失败的任务
python scripts/yarn_monitor.py --state FAILED --max-rows 20

# 查看已完成的任务
python scripts/yarn_monitor.py --state FINISHED --max-rows 20
```

**按应用ID精确点查**
```bash
python scripts/yarn_monitor.py --query application_1640577060002_4480423
```

**按应用名称模糊搜索**
```bash
python scripts/yarn_monitor.py --query "GPS_Flink_GoomeHistoryOriginalData"
```

**按队列筛选**
```bash
python scripts/yarn_monitor.py --queue root.gps --max-rows 20
```

**组合查询**
```bash
# 同时按状态和名称筛选
python scripts/yarn_monitor.py --state RUNNING --query "spark"

# 同时按队列和状态筛选
python scripts/yarn_monitor.py --queue root.spark --state FINISHED --max-rows 20
```

**查看所有匹配任务**
```bash
# 不限制行数（max-rows=0），谨慎使用大数据集
python scripts/yarn_monitor.py --state RUNNING --max-rows 0
```

**查看应用错误日志**
```bash
# 查看指定应用的错误原因（自动提取第一个Caused by及其后10行，富文本格式）
python scripts/yarn_monitor.py --show-log application_1640577060002_4727556

# 查看日志（纯文本格式）
python scripts/yarn_monitor.py --show-log application_1640577060002_4727556 --raw

# 仅查看核心错误栈（避免内容过长被折叠）
python scripts/yarn_monitor.py --show-log application_1640577060002_4727556 --raw | grep -A 20 "Caused by"
```

### 输出格式说明

工具提供两种输出模式：

1. **富文本TUI格式（默认）**: 不使用 `--raw` 参数，以彩色美观的表格展示，状态、进度等信息自动着色，方便快速识别，适合大多数场景
2. **纯文本格式**: 使用 `--raw` 参数，以简洁的纯文本表格展示，适合不支持富文本的终端或需要复制内容的场景

**默认行为**: 默认使用富文本TUI格式，显示前5条结果。

输出内容包含：
- **ID**: 应用标识符
- **用户**: 提交任务的用户
- **名称**: 应用名称
- **类型**: 应用类型（Spark、Flink等）
- **队列**: 资源队列
- **状态**: 应用状态
- **进度**: 任务执行进度百分比
- **资源使用**: 容器数、CPU、内存使用情况

### 查询结果处理

1. **完整展示结果**: 必须首先完整展示脚本执行的表格输出
2. **大文件处理**: 如果输出内容过大被自动保存到文件，需要明确告知用户文件路径，并展示完整的输出预览内容
3. **调整行数**: 如果需要查看更多任务，可以添加 `--max-rows N` 参数
4. **复制内容**: 需要复制单元格内容时，添加 `--copy` 参数获取纯净格式
5. **可选总结**: 仅当用户明确要求时提供，包括任务总数、主要任务类型分布、各状态任务数量、重要队列的任务情况、异常或高资源占用的任务
6. **筛选提示**: 结果过多时可使用`--queue`按队列筛选、`--query`按名称/ID筛选、减小`--max-rows`参数值

## 高级使用场景

### 筛选长时间运行的任务

```bash
# 查看运行超过2小时的任务（结合--state RUNNING和结果分析）
python scripts/yarn_monitor.py --state RUNNING --max-rows 50 --raw
# 然后分析Started Time字段筛选超时任务
```

### 监控资源占用异常的应用

```bash
# 查看当前运行的任务，关注Allocated CPU和Allocated Memory
python scripts/yarn_monitor.py --state RUNNING --max-rows 50 --raw
# 筛选资源占用高的应用进行分析
```

### 与DolphinScheduler配合使用

```bash
# 当DolphinScheduler任务失败时，使用应用ID点查详情
python scripts/yarn_monitor.py --query application_xxx --raw

# 查看失败任务的错误日志
python scripts/yarn_monitor.py --show-log application_xxx --raw
```

### 快速定位失败原因

```bash
# 查看失败任务列表
python scripts/yarn_monitor.py --state FAILED --max-rows 10 --raw

# 对失败任务进行日志分析
python scripts/yarn_monitor.py --show-log application_xxx --raw
```

## 常见触发短语

用户可能使用以下表述，均应触发此技能：
- "查看yarn任务"
- "查看yarn运行的任务"
- "yarn队列情况"
- "查询yarn队列的任务"
- "查询spark队列的任务"
- "查看application_xxx的任务详情"
- "yarn集群任务监控"
- "查看失败的yarn任务"
- "查看应用日志"
- "查看错误日志"
- "查看任务报错原因"
- "application_xxx 为什么失败"
- "yarn任务列表"
- "yarn有哪些任务在跑"
- "查看yarn当前任务"

## 依赖要求

- Python 3.8+
- 必需包：`requests`, `lxml`, `rich`

安装依赖：
```bash
pip install requests lxml rich
```

## 故障排除

### 常见问题

| 问题 | 原因 | 解决方法 |
|------|------|----------|
| SSL证书错误 | YARN服务端使用自签名证书 | 脚本已默认使用 `verify=False` 绕过 |
| 网络超时 | 网络延迟或集群负载高 | 修改 `fetch_yarn_page()` 函数的超时参数 |
| 输出过多导致终端卡顿 | 返回数据量大 | 使用 `--max-rows` 限制输出行数 |
| 连接失败 | YARN服务未启动或网络不通 | 检查YARN服务状态和网络连接 |
| 权限不足 | 认证失败或无访问权限 | 检查Kerberos认证或用户权限 |
| 队列不存在 | 队列名称拼写错误 | 使用 `--state` 查询所有队列验证 |
| 找不到日志URL | 应用无容器或状态不支持 | 确认应用有运行过的容器，或状态不是SUBMITTED/ACCEPTED |
| 日志中没有"Caused by" | 任务未报错或日志格式不同 | 使用 `--query` 查看任务详情，或手动访问日志页面 |

### 验证集群连接状态

```bash
# 测试基本连接（查询1条运行任务）
python scripts/yarn_monitor.py --state RUNNING --max-rows 1 --raw
```

如果连接成功，会返回表格格式的任务信息；如果失败，会显示错误信息。

### 调试模式

如需详细日志，可以在脚本中添加 `--verbose` 参数（需要脚本支持）：
```bash
python scripts/yarn_monitor.py --state RUNNING --max-rows 20 --raw --verbose
```

## 实战案例

### 案例1：排查root.spark队列资源占用高的任务

**场景**: 发现root.spark队列资源占用异常，需要定位问题任务

**步骤**:
1. 查看root.spark队列所有运行任务
   ```bash
   python scripts/yarn_monitor.py --queue root.spark --state RUNNING --max-rows 50 --raw
   ```

2. 分析输出结果，重点关注：
   - Allocated Memory和Allocated CPU列
   - Running Time列（运行时长）
   - Progress列（任务进度）

3. 找出资源占用高且进度缓慢的任务，记录应用ID

4. 对异常任务进行点查，获取详细信息
   ```bash
   python scripts/yarn_monitor.py --query application_xxx --raw
   ```

5. 根据结果决定是否需要kill或调整任务配置

### 案例2：监控DolphinScheduler失败任务

**场景**: DolphinScheduler工作流失败，需要查看YARN任务详情

**步骤**:
1. 从DolphinScheduler获取失败的应用ID（如application_xxx）

2. 使用YARN查询工具点查任务详情
   ```bash
   python scripts/yarn_monitor.py --query application_xxx --raw
   ```

3. 查看任务状态、失败原因、日志链接等信息

4. 直接查看应用的错误日志
   ```bash
   python scripts/yarn_monitor.py --show-log application_xxx --raw
   ```

5. 根据信息分析失败原因并采取相应措施

### 案例3：快速排查批量失败任务

**场景**: 某队列多个任务失败，需要快速定位共性问题

**步骤**:
1. 查看失败任务列表
   ```bash
   python scripts/yarn_monitor.py --state FAILED --queue root.spark --max-rows 20 --raw
   ```

2. 对前几个失败任务逐个查看错误日志
   ```bash
   # 查看第一个失败任务
   python scripts/yarn_monitor.py --show-log application_xxx_1 --raw

   # 查看第二个失败任务
   python scripts/yarn_monitor.py --show-log application_xxx_2 --raw
   ```

3. 对比多个任务的错误原因，识别共性问题（如：资源不足、数据问题、权限问题等）

4. 采取针对性措施解决

## 功能特性总结

- **任务状态查询**: 按RUNNING、FINISHED、FAILED、KILLED等状态筛选应用
- **队列监控**: 按队列查看任务分布情况
- **点查功能**: 按应用ID或名称精确搜索特定任务
- **灵活输出**: 支持纯文本和富文本两种格式
- **资源格式化**: 自动格式化内存和CPU使用情况
- **高效筛选**: 支持多条件组合查询
- **日志查看**: 自动提取应用错误日志，快速定位"Caused by"错误原因