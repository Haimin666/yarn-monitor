#!/usr/bin/env python3
"""
YARN Cluster Manager - Unified monitoring and management tool

This script provides comprehensive YARN cluster monitoring with:
- Beautiful TUI interface using rich library
- Application state filtering (RUNNING, FINISHED, FAILED, etc.)
- Queue usage monitoring with progress bars
- Point query by application ID or name
- Cluster metrics display

Usage examples:
    python yarn_monitor.py --state RUNNING
    python yarn_monitor.py --query application_12345
    python yarn_monitor.py --show-queues
    python yarn_monitor.py --max-rows 50
"""

import requests
import re
import sys
import argparse
from typing import Dict, List, Any
from datetime import datetime
from lxml import html
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.columns import Columns
from rich import box
from rich.text import Text

console = Console()


def format_timestamp(ts_ms: str) -> str:
    """Convert millisecond timestamp to readable datetime string."""
    if not ts_ms or ts_ms == "0":
        return "-"
    try:
        ts = int(ts_ms) / 1000
        return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, OSError):
        return "-"

def fetch_yarn_page(url: str) -> str:
    """Fetch YARN page content with proper headers."""
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36'
    }

    try:
        response = requests.get(url, headers=headers, verify=False, timeout=30)
        response.raise_for_status()
        return response.text
    except requests.RequestException as e:
        console.print(f"[red]Error fetching YARN page: {e}[/red]", file=sys.stderr)
        sys.exit(1)

def extract_queue_usage_with_percentages(html_content: str) -> List[Dict[str, Any]]:
    """Extract queue usage information with actual percentages using lxml."""
    queues = []

    try:
        doc = html.fromstring(html_content)

        # Find all queue elements with class 'q' and their corresponding stats
        queue_elements = doc.xpath('//a[contains(@class, "ui-state-default") and contains(@class, "ui-corner-all")]//span[@class="q"]')
        stats_elements = doc.xpath('//a[contains(@class, "ui-state-default") and contains(@class, "ui-corner-all")]/following-sibling::span[@class="qstats"]')

        for i, queue_elem in enumerate(queue_elements):
            queue_name = queue_elem.text_content().strip()
            usage_text = "N/A"
            usage_percent = 0.0

            if i < len(stats_elements):
                usage_text = stats_elements[i].text_content().strip()
                # Extract percentage from text like "82.1% used"
                percent_match = re.search(r'(\d+(?:\.\d+)?)%', usage_text)
                if percent_match:
                    usage_percent = float(percent_match.group(1))

            queues.append({
                'name': queue_name,
                'usage_text': usage_text,
                'usage_percent': usage_percent
            })

    except Exception as e:
        # Fallback to regex method
        queue_pattern = r'<a class="ui-state-default ui-corner-all"[^>]*><span[^>]*>\.</span><span class="q">([^<]+)</span></a><span class="qstats"[^>]*>([^<]+)</span>'
        matches = re.findall(queue_pattern, html_content)
        for queue_name, usage in matches:
            percent_match = re.search(r'(\d+(?:\.\d+)?)%', usage)
            usage_percent = float(percent_match.group(1)) if percent_match else 0.0
            queues.append({
                'name': queue_name,
                'usage_text': usage.strip(),
                'usage_percent': usage_percent
            })

    return queues

def extract_detailed_queue_info(html_content: str) -> List[Dict[str, str]]:
    """Extract detailed queue resource information using lxml."""
    detailed_queues = []

    try:
        doc = html.fromstring(html_content)

        # Find all queue info tables
        queue_tables = doc.xpath('//div[@class="info-wrap ui-widget-content ui-corner-bottom"]/table[@class="info"]')

        for table in queue_tables:
            # Extract queue name from the header
            header = table.xpath('.//th[@class="ui-state-default" and @colspan="2"]')
            if header:
                queue_name_text = header[0].text_content().strip()
                # Extract queue name from format: "'queue_name' Queue Status"
                queue_name_match = re.search(r"'([^']+)'", queue_name_text)
                if queue_name_match:
                    queue_name = queue_name_match.group(1)
                else:
                    queue_name = queue_name_text

                # Extract used resources
                used_rows = table.xpath('.//tr[@class="odd"]')
                used_resources = "N/A"
                if used_rows:
                    used_cells = used_rows[0].xpath('.//td')
                    if used_cells:
                        used_resources = used_cells[0].text_content().strip()
                        # Clean up HTML entities
                        used_resources = used_resources.replace('&lt;', '<').replace('&gt;', '>')

                # Extract demand resources
                demand_rows = table.xpath('.//tr[@class="even"]')
                demand_resources = "N/A"
                if demand_rows:
                    demand_cells = demand_rows[0].xpath('.//td')
                    if demand_cells:
                        demand_resources = demand_cells[0].text_content().strip()
                        # Clean up HTML entities
                        demand_resources = demand_resources.replace('&lt;', '<').replace('&gt;', '>')

                detailed_queues.append({
                    'name': queue_name.strip(),
                    'used_resources': used_resources.strip(),
                    'demand_resources': demand_resources.strip()
                })

    except Exception as e:
        # Fallback to regex method
        queue_info_pattern = r"<th class=\"ui-state-default\" colspan=\"2\">\s*'([^']+)' Queue Status\s*</th>.*?<tr class=\"odd\">\s*<th>\s*Used Resources:\s*</th>\s*<td>\s*([^<]+)\s*</td>\s*</tr>.*?<tr class=\"even\">\s*<th>\s*Demand Resources:\s*</th>\s*<td>\s*([^<]+)\s*</td>"
        queue_info_matches = re.findall(queue_info_pattern, html_content, re.DOTALL)
        for queue_name, used_resources, demand_resources in queue_info_matches:
            used_resources = used_resources.replace('&lt;', '<').replace('&gt;', '>')
            demand_resources = demand_resources.replace('&lt;', '<').replace('&gt;', '>')
            detailed_queues.append({
                'name': queue_name.strip(),
                'used_resources': used_resources.strip(),
                'demand_resources': demand_resources.strip()
            })

    return detailed_queues

def extract_log_url_from_app_page(html_content: str) -> str:
    """Extract log URL from application details page.

    Args:
        html_content: HTML content of application detail page

    Returns:
        Log URL string or None if not found
    """
    try:
        # Look for attemptsTableData in JavaScript
        start_marker = 'var attemptsTableData=['
        start_pos = html_content.find(start_marker)

        if start_pos == -1:
            return None

        # Extract the attempts table data
        data_start = start_pos + len(start_marker)
        bracket_count = 1
        end_pos = data_start
        in_string = False

        for i in range(data_start, len(html_content)):
            char = html_content[i]
            if char == '"' and (i == 0 or html_content[i-1] != '\\'):
                in_string = not in_string
            elif not in_string:
                if char == '[':
                    bracket_count += 1
                elif char == ']':
                    bracket_count -= 1
                    if bracket_count == 0:
                        end_pos = i + 1
                        break

        if end_pos > data_start:
            json_data = html_content[data_start:end_pos-1].strip()
            # Parse the JSON-like structure to find the log link field (index 3 in array)
            # Format: ["attempt_id", "timestamp", "node_url", "log_link", "containers", "status"]
            # We need to extract the 4th field which contains the log link
            fields = re.findall(r'"([^"]*)"', json_data)
            if len(fields) >= 4:
                log_link = fields[3]  # 4th field is the log link
                # Extract href attribute from HTML (format: <a href='URL'>Logs</a>)
                href_match = re.search(r"href=['\"]([^'\"]+)['\"]", log_link)
                if href_match:
                    log_link = href_match.group(1)
                    # Unescape the URL
                    log_link = log_link.replace('\\/', '/')
                    # Extract base URL and add stderr
                    if 'containerlogs/' in log_link:
                        # Extract the base log URL
                        base_url = re.search(r'(http://[^/]+/node/containerlogs/[^/]+/[^/]+)', log_link)
                        if base_url:
                            return f"{base_url.group(1)}/stderr/?start=0"

        return None
    except Exception as e:
        console.print(f"[red]Error extracting log URL: {e}[/red]", file=sys.stderr)
        return None

def fetch_log_content(log_url: str) -> str:
    """Fetch log content from the given URL.

    Args:
        log_url: URL to fetch logs from

    Returns:
        Log content as string
    """
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36'
    }

    try:
        response = requests.get(log_url, headers=headers, verify=False, timeout=30)
        response.raise_for_status()
        return response.text
    except requests.RequestException as e:
        console.print(f"[red]Error fetching log: {e}[/red]", file=sys.stderr)
        sys.exit(1)

def extract_error_cause(log_content: str) -> List[str]:
    """Extract error cause from log content starting from first "Caused by" until </pre> tag.

    Args:
        log_content: Log content as string (may contain HTML tags)

    Returns:
        List of extracted lines from first "Caused by" to </pre> tag
    """
    lines = log_content.split('\n')

    # Find the first occurrence of "Caused by"
    cause_line_index = -1
    for i, line in enumerate(lines):
        if 'Caused by' in line:
            cause_line_index = i
            break

    if cause_line_index == -1:
        return []

    # Find the first occurrence of </pre> after "Caused by"
    end_line_index = len(lines)
    for i in range(cause_line_index, len(lines)):
        if '</pre>' in lines[i]:
            end_line_index = i
            break

    # Extract all lines from first "Caused by" to </pre> tag
    return lines[cause_line_index:end_line_index]

def display_log_content(app_id: str, log_lines: List[str], raw: bool = False):
    """Display log content with appropriate formatting.

    Args:
        app_id: Application ID
        log_lines: List of log lines to display
        raw: Whether to use raw text output
    """
    if not log_lines:
        console.print("[yellow]No error cause found in logs.[/yellow]")
        return

    if raw:
        print(f"\n{'='*100}")
        print(f"Application ID: {app_id}")
        print(f"{'='*100}")
        print("\nError Cause:")
        print(f"{'='*100}")
        for line in log_lines:
            print(line)
    else:
        panel = Panel(
            '\n'.join(log_lines),
            title=f"[bold red]Error Cause - {app_id}[/bold red]",
            border_style="red",
            expand=False
        )
        console.print(panel)

def extract_applications_data(html_content: str) -> List[List[str]]:
    """Extract applications data from appsTableData JavaScript variable."""
    applications = []
    start_marker = 'var appsTableData=['
    start_pos = html_content.find(start_marker)

    if start_pos != -1:
        data_start = start_pos + len(start_marker)
        bracket_count = 1
        end_pos = data_start
        in_string = False

        for i in range(data_start, len(html_content)):
            char = html_content[i]
            if char == '"' and (i == 0 or html_content[i-1] != '\\'):
                in_string = not in_string
            elif not in_string:
                if char == '[':
                    bracket_count += 1
                elif char == ']':
                    bracket_count -= 1
                    if bracket_count == 0:
                        end_pos = i + 1
                        break

        if end_pos > data_start:
            json_data = html_content[data_start:end_pos-1].strip()
            if json_data:
                json_data = json_data.replace('&lt;', '<').replace('&gt;', '>')
                apps = []
                current_app = ""
                paren_level = 0
                in_quotes = False

                i = 0
                while i < len(json_data):
                    char = json_data[i]
                    if char == '"' and (i == 0 or json_data[i-1] != '\\'):
                        in_quotes = not in_quotes
                    current_app += char

                    if not in_quotes:
                        if char == '[':
                            paren_level += 1
                        elif char == ']':
                            paren_level -= 1

                    if char == ',' and not in_quotes and paren_level == 0:
                        if current_app.strip():
                            apps.append(current_app.rstrip(','))
                        current_app = ""
                    i += 1

                if current_app.strip():
                    apps.append(current_app)

                for app_str in apps:
                    if not app_str.strip():
                        continue
                    fields = []
                    app_clean = app_str.strip()
                    if app_clean.startswith('[') and app_clean.endswith(']'):
                        app_clean = app_clean[1:-1]

                    field_matches = re.findall(r'"((?:[^"\\]|\\.)*)"', app_clean)
                    if field_matches:
                        cleaned_fields = []
                        for field in field_matches:
                            field = field.replace('\\"', '"')
                            clean_field = re.sub(r'<[^>]+>', '', field)
                            if 'title=' in field:
                                progress_match = re.search(r'title=\'([^\']+)\'', field)
                                if progress_match:
                                    clean_field = progress_match.group(1)
                                    if clean_field.replace('.', '').isdigit():
                                        clean_field += '%'
                            cleaned_fields.append(clean_field.strip())

                        while len(cleaned_fields) < 21:
                            cleaned_fields.append("")
                        applications.append(cleaned_fields[:21])

    return applications

def create_applications_table(applications: List[List[str]], max_rows: int = 20, queue_filter: str = None, raw: bool = False, copy: bool = False):
    """Create applications table with optional raw text or copy-friendly format."""
    if not applications:
        if queue_filter:
            print(f"No applications found for queue: {queue_filter}")
        else:
            print("No applications found.")
        return

    display_apps = applications[:max_rows]

    # 准备公共行数据
    headers = ["ID", "User", "Type", "Queue", "State", "Progress", "Start Time", "End Time", "Name"]
    rows_data = []
    for app in display_apps:
        if len(app) >= 21:
            app_id = app[0] if len(app) > 0 else ""
            user = app[1] if len(app) > 1 else ""
            app_type = app[3] if len(app) > 3 else ""
            queue = app[4] if len(app) > 4 else ""
            state = app[9] if len(app) > 9 else "UNKNOWN"
            progress = app[18] if len(app) > 18 else ""
            start_time = format_timestamp(app[6]) if len(app) > 6 else "-"
            end_time = format_timestamp(app[7]) if len(app) > 7 else "-"
            name = app[2] if len(app) > 2 else ""

            row = [app_id, user, app_type, queue, state, progress, start_time, end_time, name]
            rows_data.append(row)

    if copy:
        # Copy-friendly format - 专为复制优化，无边框无颜色，列对齐
        print(f"Applications List (Showing {len(display_apps)} of {len(applications)} total)")
        if queue_filter:
            print(f"Filtered by Queue: {queue_filter}")
        print()

        # 计算每列最大宽度
        col_widths = [len(h) for h in headers]
        for row in rows_data:
            for i, val in enumerate(row):
                if len(val) > col_widths[i]:
                    col_widths[i] = min(len(val), 60)  # 适当放宽最大宽度

        # 打印表头
        header_line = ""
        for i, h in enumerate(headers):
            header_line += f"{h.ljust(col_widths[i])}  "
        print(header_line)
        print("-" * (sum(col_widths) + len(headers) * 2))

        # 打印数据行
        for row in rows_data:
            line = ""
            for i, val in enumerate(row):
                display_val = val[:col_widths[i]]
                line += f"{display_val.ljust(col_widths[i])}  "
            print(line)

        if len(applications) > max_rows:
            print(f"\nNote: Showing only first {max_rows} applications. Total: {len(applications)}")
        return

    if raw:
        # Raw text format - 美观的纯文本表格，方便人类阅读
        print(f"\nApplications List (Showing {len(display_apps)} of {len(applications)} total)")
        if queue_filter:
            print(f"Filtered by Queue: {queue_filter}")

        # 计算每列的最大宽度（至少和表头一样宽）
        col_widths = [len(h) for h in headers]
        for row in rows_data:
            for i, val in enumerate(row):
                if len(val) > col_widths[i]:
                    col_widths[i] = min(len(val), 50)  # 限制最大宽度防止太宽

        # 打印表头分隔线
        separator = "+" + "+".join(["-" * (w + 2) for w in col_widths]) + "+"
        print(separator)

        # 打印表头
        header_line = "|"
        for i, h in enumerate(headers):
            header_line += f" {h.ljust(col_widths[i])} |"
        print(header_line)
        print(separator)

        # 打印数据行
        for row in rows_data:
            line = "|"
            for i, val in enumerate(row):
                # 超过宽度的部分截断显示...
                display_val = val[:col_widths[i]-3] + "..." if len(val) > col_widths[i] else val
                line += f" {display_val.ljust(col_widths[i])} |"
            print(line)

        print(separator)

        if len(applications) > max_rows:
            print(f"\nNote: Showing only first {max_rows} applications. Total: {len(applications)}")
        return

    # Rich TUI format
    title = f"[bold]Applications List[/bold] (Showing {len(display_apps)} of {len(applications)} total)"
    if queue_filter:
        title += f" - Filtered by Queue: {queue_filter}"

    table = Table(
        title=title,
        box=box.ROUNDED,
        show_header=True,
        header_style="bold blue",
        expand=True
    )

    table.add_column("ID", style="green", no_wrap=False, overflow="fold")
    table.add_column("User", style="yellow", no_wrap=False, overflow="fold")
    table.add_column("Name", style="cyan", no_wrap=False, overflow="fold")
    table.add_column("Type", style="magenta", no_wrap=False, overflow="fold")
    table.add_column("Queue", style="blue", no_wrap=False, overflow="fold")
    table.add_column("State", no_wrap=False, overflow="fold")
    table.add_column("Progress", style="green", no_wrap=False, overflow="fold")
    table.add_column("Start Time", style="white", no_wrap=False, overflow="fold")
    table.add_column("End Time", style="white", no_wrap=False, overflow="fold")

    for app in display_apps:
        if len(app) >= 21:
            state = app[9] if len(app) > 9 else "UNKNOWN"
            if state == "RUNNING":
                state_style = "green"
            elif state in ["FAILED", "KILLED"]:
                state_style = "red"
            elif state in ["SUBMITTED", "ACCEPTED"]:
                state_style = "yellow"
            else:
                state_style = "white"

            # No masking for ID field - show full ID
            app_id = app[0] if len(app) > 0 else ""
            start_time = format_timestamp(app[6]) if len(app) > 6 else "-"
            end_time = format_timestamp(app[7]) if len(app) > 7 else "-"

            row_data = [
                app_id,
                app[1] if len(app) > 1 else "",
                app[2] if len(app) > 2 else "",
                app[3] if len(app) > 3 else "",
                app[4] if len(app) > 4 else "",
                f"[{state_style}]{state}[/{state_style}]",
                app[18] if len(app) > 18 else "",
                start_time,
                end_time
            ]
            table.add_row(*row_data)

    console.print(table)
    if len(applications) > max_rows:
        console.print(f"[yellow]Note: Showing only first {max_rows} applications. Total: {len(applications)}[/yellow]")

def filter_applications_by_query(applications: List[List[str]], query: str) -> List[List[str]]:
    """Filter applications by query string with exact ID match priority.

    Args:
        applications: List of application data rows
        query: Query string to search for

    Returns:
        List of matching applications. If exact ID match found, returns single result.
        Otherwise returns all fuzzy name matches.
    """
    if not query:
        return applications

    # First pass: check for exact ID match
    for app in applications:
        if len(app) > 0 and app[0] == query:
            return [app]  # Return immediately on exact ID match

    # Second pass: fuzzy name matching (case-insensitive)
    filtered_apps = []
    for app in applications:
        if len(app) > 2 and app[2] and query.lower() in app[2].lower():
            filtered_apps.append(app)

    return filtered_apps

def filter_applications_by_queue(applications: List[List[str]], queue_name: str) -> List[List[str]]:
    """Filter applications by queue name (exact match or pattern match)."""
    if not queue_name:
        return applications

    # Use list comprehension for better performance
    queue_col_index = 4  # Queue is at index 4 in the applications data
    return [
        app for app in applications
        if queue_col_index < len(app) and (
            queue_name == app[queue_col_index] or queue_name in app[queue_col_index]
        )
    ]

def create_progress_bar(percentage: float, width: int = 20) -> str:
    """Create a visual progress bar with rich text formatting."""
    if percentage <= 0:
        filled_width = 0
    elif percentage >= 100:
        filled_width = width
    else:
        filled_width = int(width * percentage / 100)

    empty_width = width - filled_width

    # Choose color based on usage level
    if percentage >= 90:
        bar_color = "red"
    elif percentage >= 80:
        bar_color = "yellow"
    elif percentage >= 60:
        bar_color = "cyan"
    else:
        bar_color = "green"

    filled = "█" * filled_width
    empty = "░" * empty_width

    return f"[{bar_color}]{filled}[/{bar_color}]{empty}"

def create_queue_usage_table(queues: List[Dict[str, Any]], detailed_queues: List[Dict[str, str]]):
    """Create queue usage table with rich formatting and progress bars."""
    if not queues:
        console.print("[yellow]No queue information found.[/yellow]")
        return

    # Create usage summary table with progress bars (without separate percentage column)
    usage_table = Table(
        title="[bold]Queue Usage Summary[/bold]",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold blue",
        expand=True
    )

    usage_table.add_column("Queue Name", style="cyan", no_wrap=False, overflow="fold")
    usage_table.add_column("Progress", style="yellow", no_wrap=False, overflow="fold")
    usage_table.add_column("Usage Details", style="green", no_wrap=False, overflow="fold")

    for queue in queues:
        percent = queue['usage_percent']
        progress_bar = create_progress_bar(percent)

        usage_table.add_row(queue['name'], progress_bar, queue['usage_text'])

    console.print(usage_table)

    # Create detailed resource table if available
    if detailed_queues:
        resource_table = Table(
            title="[bold]Detailed Queue Resource Information[/bold]",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold blue",
            expand=True
        )

        resource_table.add_column("Queue Name", style="cyan", no_wrap=False, overflow="fold")
        resource_table.add_column("Used Resources", style="green", no_wrap=False, overflow="fold")
        resource_table.add_column("Demand Resources", style="magenta", no_wrap=False, overflow="fold")

        for queue in detailed_queues:
            resource_table.add_row(
                queue['name'],
                queue['used_resources'],
                queue['demand_resources']
            )

        console.print(resource_table)

def main():
    parser = argparse.ArgumentParser(description='YARN Cluster Manager')
    parser.add_argument('--state', choices=['SUBMITTED', 'ACCEPTED', 'RUNNING', 'FINISHED', 'FAILED', 'KILLED'],
                       help='Filter applications by state')
    parser.add_argument('--query', help='Search for specific application by ID or name')
    parser.add_argument('--url', default='http://hadoop-nn-1.bigdata.shiqiao.com:8088/cluster',
                       help='YARN ResourceManager URL')
    parser.add_argument('--show-queues', action='store_true',
                       help='Show queue usage monitor instead of applications')
    parser.add_argument('--queue', help='Show applications for specific queue (e.g., root.gps)')
    parser.add_argument('--max-rows', type=int, default=5,
                       help='Maximum number of applications to display (default: 5, set to 0 to show all)')
    parser.add_argument('--simple', action='store_true',
                       help='Simple output mode - only show applications table without decorations')
    parser.add_argument('--raw', action='store_true',
                       help='Raw text output mode - no rich formatting, plain text only')
    parser.add_argument('--copy', action='store_true',
                       help='Copy-friendly output mode - optimized for easy text copying, no borders or colors')
    parser.add_argument('--show-log', help='Show error cause for a specific application ID (e.g., application_xxx)')

    args = parser.parse_args()

    # Handle --show-log mode
    if args.show_log:
        if not args.simple and not args.raw:
            console.print(Panel.fit(
                "[bold cyan]YARN Cluster Manager - Log Viewer[/bold cyan]\n"
                f"Viewing logs for: [yellow]{args.show_log}[/yellow]",
                border_style="blue"
            ))

        # Build application detail page URL
        app_detail_url = f"http://hadoop-nn-1.bigdata.shiqiao.com:8088/cluster/app/{args.show_log}"

        if not args.simple and not args.raw:
            console.print(f"[dim]Fetching application details from: {app_detail_url}[/dim]\n")

        # Fetch application detail page
        app_page_content = fetch_yarn_page(app_detail_url)

        # Extract log URL
        log_url = extract_log_url_from_app_page(app_page_content)

        if not log_url:
            console.print(f"[red]Error: Could not find log URL for application {args.show_log}[/red]")
            console.print("[yellow]Possible reasons:[/yellow]")
            console.print("  - Application has no containers")
            console.print("  - Application is still in SUBMITTED or ACCEPTED state")
            console.print("  - Log files are not yet available")
            sys.exit(1)

        if not args.simple and not args.raw:
            console.print(f"[dim]Found log URL: {log_url}[/dim]\n")

        # Fetch log content
        log_content = fetch_log_content(log_url)

        # Extract error cause (from first "Caused by" until end of log)
        error_lines = extract_error_cause(log_content)

        # Display result
        display_log_content(args.show_log, error_lines, args.raw)

        return

    # Determine the URL based on what we're fetching
    if args.show_queues or args.queue:
        # For queue information, we need to fetch the scheduler page
        scheduler_url = args.url.replace('/cluster', '/cluster/scheduler') if '/cluster' in args.url else args.url + '/scheduler'
        url_to_fetch = scheduler_url
    elif args.state:
        # For state filtering, use the apps endpoint
        base_url = "http://hadoop-nn-1.bigdata.shiqiao.com:8088/cluster/apps"
        state_urls = {
            'SUBMITTED': f'{base_url}/SUBMITTED',
            'ACCEPTED': f'{base_url}/ACCEPTED',
            'RUNNING': f'{base_url}/RUNNING',
            'FINISHED': f'{base_url}/FINISHED',
            'FAILED': f'{base_url}/FAILED',
            'KILLED': f'{base_url}/KILLED'
        }
        url_to_fetch = state_urls.get(args.state.upper(), args.url)
    else:
        # Default to cluster page for applications
        url_to_fetch = args.url

    if not args.simple and not args.raw and not args.copy:
        # Header
        console.print(Panel.fit(
            "[bold cyan]YARN Cluster Manager[/bold cyan]\n"
            "Unified monitoring and management for YARN clusters",
            border_style="blue"
        ))

        console.print(f"[dim]Fetching data from: {url_to_fetch}[/dim]\n")

    # Fetch the page content
    html_content = fetch_yarn_page(url_to_fetch)

    if args.show_queues:
        # Extract and display queue information
        queues = extract_queue_usage_with_percentages(html_content)
        detailed_queues = extract_detailed_queue_info(html_content)
        create_queue_usage_table(queues, detailed_queues)
        return

    # Extract applications data once
    applications = extract_applications_data(html_content)

    # Apply queue filter first (if specified)
    if args.queue:
        applications = filter_applications_by_queue(applications, args.queue)

    # Apply query filter second (if specified)
    if args.query:
        applications = filter_applications_by_query(applications, args.query)
        console.print(f"[bold]🔍 Search Results for '{args.query}'[/bold]")

    # Display applications table
    if args.queue:
        create_applications_table(applications, args.max_rows, args.queue, args.raw, args.copy)
    else:
        create_applications_table(applications, args.max_rows, raw=args.raw, copy=args.copy)

    # Add summary information to avoid output being folded
    if len(applications) > 0 and not args.raw and not args.copy:
        console.print("\n[bold cyan]📊 任务统计摘要:[/bold cyan]")
        state_count = {}
        type_count = {}
        queue_count = {}

        for app in applications:
            if len(app) > 9:
                state = app[9]
                state_count[state] = state_count.get(state, 0) + 1
            if len(app) > 3:
                app_type = app[3]
                type_count[app_type] = type_count.get(app_type, 0) + 1
            if len(app) > 4:
                queue = app[4]
                queue_count[queue] = queue_count.get(queue, 0) + 1

        console.print(f"  总任务数: [green]{len(applications)}[/green]")
        if state_count:
            console.print(f"  状态分布: {', '.join([f'{k}: [yellow]{v}[/yellow]' for k, v in state_count.items()])}")
        if type_count:
            console.print(f"  类型分布: {', '.join([f'{k}: [magenta]{v}[/magenta]' for k, v in type_count.items() if k])}")
        if queue_count and len(queue_count) <= 3:
            console.print(f"  队列分布: {', '.join([f'{k}: [blue]{v}[/blue]' for k, v in queue_count.items()])}")
        elif queue_count:
            top_queues = sorted(queue_count.items(), key=lambda x: x[1], reverse=True)[:3]
            console.print(f"  主要队列: {', '.join([f'{k}: [blue]{v}[/blue]' for k, v in top_queues])} 等{len(queue_count)}个队列")

        if args.max_rows > 0 and len(applications) > args.max_rows:
            console.print(f"\n[dim]💡 提示: 使用 --max-rows 0 参数查看全部 {len(applications)} 个任务[/dim]")
            console.print(f"[dim]💡 筛选提示: 使用 --queue 按队列筛选、--query 按名称/ID筛选可减少返回内容[/dim]")
    elif len(applications) > 0 and args.raw:
        # Raw mode summary
        print("\n任务统计摘要:")
        state_count = {}
        type_count = {}
        queue_count = {}

        for app in applications:
            if len(app) > 9:
                state = app[9]
                state_count[state] = state_count.get(state, 0) + 1
            if len(app) > 3:
                app_type = app[3]
                type_count[app_type] = type_count.get(app_type, 0) + 1
            if len(app) > 4:
                queue = app[4]
                queue_count[queue] = queue_count.get(queue, 0) + 1

        print(f"总任务数: {len(applications)}")
        if state_count:
            print(f"状态分布: {', '.join([f'{k}: {v}' for k, v in state_count.items()])}")
        if type_count:
            print(f"类型分布: {', '.join([f'{k}: {v}' for k, v in type_count.items() if k])}")
        if queue_count and len(queue_count) <= 3:
            print(f"队列分布: {', '.join([f'{k}: {v}' for k, v in queue_count.items()])}")
        elif queue_count:
            top_queues = sorted(queue_count.items(), key=lambda x: x[1], reverse=True)[:3]
            print(f"主要队列: {', '.join([f'{k}: {v}' for k, v in top_queues])} 等{len(queue_count)}个队列")

        if args.max_rows > 0 and len(applications) > args.max_rows:
            print(f"\n提示: 使用 --max-rows 0 参数查看全部 {len(applications)} 个任务")
            print(f"提示: 使用 --queue 按队列筛选、--query 按名称/ID筛选可减少返回内容")

if __name__ == "__main__":
    main()